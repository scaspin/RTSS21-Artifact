import os
import sys
import multiprocessing
import time

import random
from random import shuffle
from itertools import izip
from functools import partial
from datetime import datetime
from collections import defaultdict
import math

from toolbox.io import one_of, Config, write_data
from toolbox.sample import value_range
from toolbox.stats import mean

from schedcat.model.tasks import SporadicTask, TaskSystem
from schedcat.model.resources import initialize_resource_model, ResourceRequirement
import schedcat.generator.tasksets as gen
import schedcat.generator.generator_emstada as emstada

import schedcat.locking.bounds as locking
import schedcat.sched.edf as independent_edf

from  schedcat.generator.tasks import uniform_int, log_uniform_int, uniform_choice, uniform

from schedcat.util.time import ms2us
from schedcat.util.time import ms27s

import schedcat.model.serialize as ser

# timeout value for LP construction and solving
TIMEOUT = 1 # in seconds

# RTSS '21 comparison
RTSS2021 = True

# go to smaller granularity
MORE_GRANULAR = False

# request all of the number of resources, not with probability
STRESS_TEST = False

# case study of only overheads
CASE_STUDY = False

# overhead variables
APPLY_OVERHEAD = False
if APPLY_OVERHEAD or CASE_STUDY:
    MORE_GRANULAR = True
WRITE_OVERHEAD = {}
READ_OVERHEAD = {}
if APPLY_OVERHEAD or CASE_STUDY:
    WRITE_OVERHEAD["NEW-LP"] =        9 #0.864 - 8 cores up to 10% writes
    WRITE_OVERHEAD["NEW-inflation"] = 9
    WRITE_OVERHEAD["PFTL-LP"] =          17 #1.72 - 8 cores up to 10% writes
    WRITE_OVERHEAD["PFTL-inflation"] =   17
    WRITE_OVERHEAD["NOLOCK"] =         0
    WRITE_OVERHEAD["NONE-LP"] =        0
    WRITE_OVERHEAD["NONE-inflation"] = 0
    READ_OVERHEAD["NEW-LP"] =        5 #0.5135 - 8 cores up to 10% writes
    READ_OVERHEAD["NEW-inflation"] = 5
    READ_OVERHEAD["PFTL-LP"] =          22 #2.1997 - 8 cores up to 10% writes
    READ_OVERHEAD["PFTL-inflation"] =   22
    READ_OVERHEAD["NOLOCK"] =         0
    READ_OVERHEAD["NONE-LP"] =        0
    READ_OVERHEAD["NONE-inflation"] = 0
    READ_OVERHEAD["PF-T-Overhead"] =     12  # 1.156 - 8 cores 0% wries
    READ_OVERHEAD["PF-L-Overhead"] =      2  # 0.206 - 8 cores 0% writes


# directory and file name prefix for taskset files
current_taskset_dir    = "/tmp/"
current_taskset_prefix = "pedf_lp_current_taskset"


# ############### ANALYSIS ###############


def independent_edf_test(taskset):
    # Assumes task set has already been partitioned
    # Split by partition
    partitions = defaultdict(TaskSystem)
    for t in taskset:
        partitions[t.partition].append(t)
    #print "No blocking test..."
    # apply QPA to each partition
    for cpu in partitions:
        if not independent_edf.is_schedulable(1, partitions[cpu]):
            # infeasible even without blocking
            return False
    return True

def independent_pftl_test(taskset):
    # Assumes task set has already been partitioned

    ts = taskset.copy();

    # Split by partition
    partitions = defaultdict(TaskSystem)
    for t in ts:
        partitions[t.partition].append(t)
        t.response_time = t.deadline

    locking.apply_phase_fair_rw_bounds(ts, len(partitions))

    # Test schedulability on each partition
    for cpu in partitions:
        if not independent_edf.is_schedulable(1, partitions[cpu]):
            return False
    return True

def pftl_inflate_collapse(taskset):
    partitions = defaultdict(TaskSystem)
    for t in taskset:
        partitions[t.partition].append(t)
    num_cpus = len(partitions)

    #ts = taskset.copy()
    new_tasks = []

    #replace task model
    for task_num in range(0, len(taskset)):
        old_task = taskset[task_num]
        new_task = SporadicTask(old_task.cost, old_task.period, old_task.deadline, old_task.id)
        new_tasks.append(new_task)

    ts = TaskSystem(new_tasks)
    initialize_resource_model(ts)
    locking.assign_edf_preemption_levels(ts)

    braindead_partition(num_cpus, ts)

    #replace task model
    for task_num in range(0, len(taskset)):
        old_task = taskset[task_num]
        new_task = ts[task_num]
        if old_task.cost != new_task.cost:
            print "problem with match up!!!!!!"
        #reset resources
        if len(old_task.resmodel)==0:
            continue

        num_reads = 0
        read_len = 0
        num_writes = 0
        write_len = 0
        #initializing new resource models
        for old_req_index in old_task.resmodel:
            old_req = old_task.resmodel[old_req_index]

            num_reads += old_req.get_max_reads
            read_len = max(read_len, old_req.get_max_read_length)

            num_writes += old_req.get_max_writes
            write_len = max(write_len, old_req.get_max_write_length)

        new_task.resmodel[0] = ResourceRequirement(0, num_writes, write_len, num_reads, read_len)


    for task_num in range(0, len(ts)):
        t = ts[task_num]
        old_task = taskset[task_num]
        for req_ind in old_task.resmodel:
            req = old_task.resmodel[req_ind]
            i = req.res_id
            n = i
            req = t.resmodel[0]
            oldreq = taskset[task_num].resmodel[n]

    partitions = defaultdict(TaskSystem)
    for t in ts:
        partitions[t.partition].append(t)
        t.response_time = t.deadline

    locking.apply_phase_fair_rw_bounds(ts, len(partitions))

    # Test schedulability on each partition
    for cpu in partitions:
        if not independent_edf.is_schedulable(1, partitions[cpu]):
            return False
    return True

def lp_msrp_test_helper(taskset, return_dict):
    return_dict[0] = locking.pedf_msrp_is_schedulable(taskset)

def timeout_lp_msrp_test(taskset):
    # print "LP MSRP test with timeout..."
    # All the heavy-lifting happens in C++.

    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    p = multiprocessing.Process(target=lp_msrp_test_helper, args=(taskset, return_dict))

    p.start()
    p.join(TIMEOUT)
    if p.is_alive():
        print "Timeout value (" + str(TIMEOUT) + ") reached, killing process and recording as unschedulable"
        p.terminate()
        p.join()
    if return_dict:
       return return_dict[0]
    else:
       return False

def lp_msrp_test(taskset):
    #print "LP MSRP test..."
    # All the heavy-lifting happens in C++.
    return locking.pedf_msrp_is_schedulable(taskset)

def lp_fifo_preempt_test(taskset):
    #print "LP FIFO PREEMPT test..."
    # All the heavy-lifting happens in C++.
    return locking.pedf_fifo_preempt_is_schedulable(taskset)

def msrp_classic_test(taskset):
    partitions = defaultdict(TaskSystem)
    for t in taskset:
        partitions[t.partition].append(t)
    #print "MSRP CLASSIC test..."  
    # All the heavy-lifting happens in C++.
    return locking.pedf_msrp_classic_is_schedulable(taskset, len(partitions))

def lp_lockfree_preempt_test(taskset):
    #print "LP Lock-Free PREEMPT test...
    # All the heavy-lifting happens in C++.
    return locking.pedf_lockfree_preempt_is_schedulable(taskset)    

def lp_lockfree_NP_test(taskset):
    #print "LP Lock-Free NP test..."
    # All the heavy-lifting happens in C++.
    return locking.pedf_lockfree_NP_is_schedulable(taskset)        

def tl2_test(taskset):
    return locking.tl2_is_schedulable(taskset)

def tl2_test_collapse(taskset):
    partitions = defaultdict(TaskSystem)
    for t in taskset:
        partitions[t.partition].append(t)
    num_cpus = len(partitions)

    #ts = taskset.copy()
    new_tasks = []

    #replace task model
    for task_num in range(0, len(taskset)):
        old_task = taskset[task_num]
        new_task = SporadicTask(old_task.cost,old_task.period, old_task.deadline, old_task.id)
        new_tasks.append(new_task)

    ts = TaskSystem(new_tasks)
    initialize_resource_model(ts)
    locking.assign_edf_preemption_levels(ts)

    braindead_partition(num_cpus, ts)

    #replace task model
    for task_num in range(0, len(taskset)):
        old_task = taskset[task_num]
        new_task = ts[task_num]
        if old_task.cost != new_task.cost:
            print "problem with match up!!!!!!"
        if len(old_task.resmodel)==0:
            continue

        num_reads = 0
        read_len = 0
        num_writes = 0
        write_len = 0
        for old_req_index in old_task.resmodel:
            old_req = old_task.resmodel[old_req_index]

            num_reads += old_req.get_max_reads
            read_len = max(read_len, old_req.get_max_read_length)

            num_writes += old_req.get_max_writes
            write_len = max(write_len, old_req.get_max_write_length)

        new_task.resmodel[0] = ResourceRequirement(0, num_writes, write_len, num_reads, read_len)

    return locking.tl2_is_schedulable(ts)

def lp_rwpf_test_helper(taskset, return_dict):
    return_dict[0] = locking.rw_phase_fair_is_schedulable(taskset)

def timeout_lp_rwpf_test(taskset):
    manager = multiprocessing.Manager()
    return_dict = manager.dict()
    p = multiprocessing.Process(target=lp_msrp_rwpf_helper, args=(taskset, return_dict))

    p.start()
    p.join(TIMEOUT)
    if p.is_alive():
        print "Timeout value (" + str(TIMEOUT) + ") reached, killing process and recording as unschedulable"
        p.terminate()
        p.join()
    if return_dict:
       return return_dict[0]
    else:
       return False

def rw_phase_fair_test(taskset):
    return locking.rw_phase_fair_is_schedulable(taskset);

def rw_phase_fair_test_collapse(taskset):
    partitions = defaultdict(TaskSystem)
    for t in taskset:
        partitions[t.partition].append(t)
    num_cpus = len(partitions)

    #ts = taskset.copy()
    new_tasks = []

    #replace task model
    for task_num in range(0, len(taskset)):
        old_task = taskset[task_num]
        new_task = SporadicTask(old_task.cost,old_task.period, old_task.deadline, old_task.id)
        new_tasks.append(new_task)

    ts = TaskSystem(new_tasks)
    initialize_resource_model(ts)
    locking.assign_edf_preemption_levels(ts)

    braindead_partition(num_cpus, ts)

    #replace task model
    for task_num in range(0, len(taskset)):
        old_task = taskset[task_num]
        new_task = ts[task_num]
        if old_task.cost != new_task.cost:
            print "problem with match up!!!!!!"
        if len(old_task.resmodel)==0:
            continue

        num_reads = 0
        read_len = 0
        num_writes = 0
        write_len = 0
        for old_req_index in old_task.resmodel:
            old_req = old_task.resmodel[old_req_index]

            num_reads += old_req.get_max_reads
            read_len = max(read_len, old_req.get_max_read_length)

            num_writes += old_req.get_max_writes
            write_len = max(write_len, old_req.get_max_write_length)

        new_task.resmodel[0] = ResourceRequirement(0, num_writes, write_len, num_reads, read_len)

    return locking.rw_phase_fair_is_schedulable(ts)

# ############### SCHEDULABILITY TESTS ###############

def setup_tests(conf):
    if RTSS2021:
        return [
            ("NOLOCK", independent_edf_test),
            ("pftl-blocking", independent_pftl_test),
            ("Phase-Fair-RW", rw_phase_fair_test),
            ("lockfree_NP", lp_lockfree_NP_test),
            ("lockfree_NP_no_reads", lp_lockfree_NP_test)
           ]
    if APPLY_OVERHEAD:
        return [
            ("NOLOCK", independent_edf_test),
            ("NEW-inflation", independent_pftl_test),
            ("PFTL-inflation", independent_pftl_test),
            ("NEW-LP", rw_phase_fair_test),
            ("PFTL-LP", rw_phase_fair_test)
           ]
    if CASE_STUDY:
        return [
            ("NOLOCK", independent_edf_test),
            ("PF-L-Overhead", independent_edf_test),
            ("PF-T-Overhead", independent_edf_test)
        ]
    return [
        ("no-blocking", independent_edf_test),
        ("pftl-blocking", independent_pftl_test),
        ("Phase-Fair-RW", rw_phase_fair_test)
]

# ###############   HELPER    ###############

def human_print(taskset, max_cpu):
    
    for cpuid in range(0,max_cpu):
        print "CPU #%d" % cpuid
        U = 0
        for t in taskset:
            if(t.partition==cpuid):
                U = U + (t.cost/float(t.period))
                print t
                for resid in range(1, len(t.resmodel)):
                    if t.resmodel[resid].max_requests>0:
                        print "N = %d" % t.resmodel[resid].max_requests
                        print "L = %d" % t.resmodel[resid].max_length
        
        print U
            
# ############### EXPERIMENTS ###############

def run_tcount(conf, tests, titles):
    count = 0
    rw_titles = ['pftl-blocking','pftl-collapse','Phase-Fair-RW','ILP-no-help','Phase-Fair-RW-Collapse','TL2','TL2-collapse']
    mutex_titles = ['MSRP-LP','FIFO-PREEMPT-LP','MSRP-classic','Lock-Free-PREEMPT-LP',
                    'Lock-Free-NP-LP', 'lockfree_NP']
    no_reads_titles = ['lockfree_NP_no_reads']

    for n in range(conf.tasks_min, conf.tasks_max + 1, conf.step_size):
        print "[%d @ %s] n:\t%s" % (os.getpid(), datetime.now(), n)

        utils = []
        samples = [[] for _ in tests]

        for sample in xrange(conf.samples):
            if APPLY_OVERHEAD:
                ts_dict = conf.make_taskset_overhead(n)

                # flush out taskset to disk for potential post-mortem analysis
                ser.write(ts_dict["NOLOCK"], "%s/%s_pid-%d.ts" % \
                    (current_taskset_dir, current_taskset_prefix, os.getpid()))

                utils.append(ts_dict["NOLOCK"].utilization())

                # For every test i...
                for i in xrange(len(tests)):
                    # This assumes that the no-blocking test is the first in tests.
                    if i == 0: # This is the no-blocking test. We need to run this in any case.
                        samples[i].append(tests[i](ts_dict["NOLOCK"]))
                    else:
                        # This is one of the tests considering potential blocking.
                        # Did the no-blocking test succeed?
                        if samples[0][-1]:
                            # Yes, this taskset is schedulable without blocking, so let's run our
                            # analysis to see whether it's schedulable with blocking.

                            # if ours && pftl ran && pftl succeeded
                            if titles[i] == "NEW-LP" and "NEW-inflation" in titles and samples[titles.index("NEW-inflation")][-1]:
                                samples[i].append(True)
                            elif titles[i] == "PFTL-LP" and "PFTL-inflation" in titles and samples[titles.index("PFTL-inflation")][-1]:
                                samples[i].append(True)
                            elif titles[i] == "NONE-LP" and "NONE-inflation" in titles and samples[titles.index("NONE-inflation")][-1]:
                                samples[i].append(True)
                            else:
                                samples[i].append(tests[i](ts_dict[titles[i]]))
                        else:
                            # No, the taskset is not even schedulable without blocking, so it cannot
                            # possibly be schedulable with blocking.
                            samples[i].append(False)
            elif CASE_STUDY:
                ts_dict = conf.make_taskset_case_study(n)

                # flush out taskset to disk for potential post-mortem analysis
                ser.write(ts_dict["NOLOCK"], "%s/%s_pid-%d.ts" % \
                    (current_taskset_dir, current_taskset_prefix, os.getpid()))

                utils.append(ts_dict["NOLOCK"].utilization())

                # For every test i...
                for i in xrange(len(tests)):
                    # This assumes that the no-blocking test is the first in tests.
                    if i == 0: # This is the no-blocking test. We need to run this in any case.
                        samples[i].append(tests[i](ts_dict["NOLOCK"]))
                    else:
                        # This is one of the tests considering potential overhead.
                        # Did the no-overhead test succeed?
                        if samples[0][-1]:
                            # Yes, this taskset is schedulable without overheads, so let's run our
                            # analysis to see whether it's schedulable with overheads.
                            samples[i].append(tests[i](ts_dict[titles[i]]))
                        else:
                            # No, the taskset is not even schedulable without overheads, so it cannot
                            # possibly be schedulable with overheads.
                            samples[i].append(False)
            else:
                (taskset_rw, taskset_mutex, taskset_no_reads) = conf.make_taskset(n)

                # flush out taskset to disk for potential post-mortem analysis
                ser.write(taskset_rw, "%s/%s_pid-%d.ts" % \
                    (current_taskset_dir, current_taskset_prefix, os.getpid()))

                utils.append(taskset_rw.utilization())

                # For every test i...
                for i in xrange(len(tests)):
                    # This assumes that the no-blocking test is the first in tests.
                    if i == 0: # This is the no-blocking test. We need to run this in any case.
                        samples[i].append(tests[i](taskset_mutex))
                    else:
                        # This is one of the tests considering potential blocking.
                        # Did the no-blocking test succeed?
                        if samples[0][-1]:
                            # Yes, this taskset is schedulable without blocking, so let's run our
                            # analysis to see whether it's schedulable with blocking.
                            if titles[i] in rw_titles:
                                if (titles[i] == "Phase-Fair-RW") and ("pftl-blocking" in titles) and ("ILP-no-help" in titles):
                                    if samples[titles.index("pftl-blocking")][-1] or samples[titles.index("ILP-no-help")][-1]:
                                        samples[i].append(True)
                                    else:
                                        samples[i].append(False)
                                # if ours && pftl ran && pftl succeeded
                                elif titles[i] == "Phase-Fair-RW" and "pftl-blocking" in titles and samples[titles.index("pftl-blocking")][-1]:
                                    samples[i].append(True)
                                elif titles[i] == "Phase-Fair-RW-Collapse" and "pftl-collapse" in titles and samples[titles.index("pftl-collapse")][-1]:
                                    samples[i].append(True)
                                else:
                                    samples[i].append(tests[i](taskset_rw))
                            elif titles[i] in mutex_titles:
                                samples[i].append(tests[i](taskset_mutex))
                            elif titles[i] in no_reads_titles:
                                samples[i].append(tests[i](taskset_no_reads))
                            else:
                                print "Error: Please specify if this test should use taskset_rw or taskset_mutex."
                        else:
                            # No, the taskset is not even schedulable without blocking, so it cannot
                            # possibly be schedulable with blocking.
                            samples[i].append(False)

        print '=> min-u:%.2f avg-u:%.2f max-u:%.2f' % (min(utils), sum(utils) / len(utils), max(utils))
        row = []
        for i in xrange(len(tests)):
            row.append(mean(samples[i]))

        yield [n] + ['%.2f' % x for x in row]

# ############### TASK SET GENERATION ###############

def braindead_partition(num_cpus, taskset):
    # clearly, something smarter would be desirable...
    # standard resource-oblivious heuristics are available in schedcat.mapping
    for i, t in enumerate(taskset):
        t.partition = i % num_cpus

def draw_cs_count(conf):
    if STRESS_TEST:
        return conf.max_requests
    elif random.random() <= conf.access_prob:
        # access resource
        return random.randint(1, conf.max_requests)
    else:
        return 0

def draw_cs_count_rw(conf):
    random_access = random.random()
    if random_access <= conf.access_prob:
        # access resource
        if STRESS_TEST:
            total_num_access = conf.max_requests
        else:
            total_num_access = random.randint(1, conf.max_requests)

    #    print "total_num_access: "+str(total_num_access)

        write_access = 0
        read_access = 0
        for x in range(total_num_access):
            random_RW = random.random()
            if random_RW <= conf.write_prob:
                write_access += 1
            else:
                read_access += 1
        return (write_access, read_access)
    else:
        return (0, 0)
if MORE_GRANULAR:
    CSLENGTH  = {
        'uni-1-5'       : lambda: random.randint(10,   50),
        'uni-1-10'      : lambda: random.randint(10,   100),
        'short'         : lambda: random.randint(10,   250),
        'medium'        : lambda: random.randint(250,  1000),
        'long'          : lambda: random.randint(1000, 5000),
        'extreme'       : lambda: random.randint(1000, 10000),
    }
else:
    CSLENGTH  = {
        'uni-1-5'       : lambda: random.randint(1,   5),
        'uni-1-10'      : lambda: random.randint(1,   10),
        'short'         : lambda: random.randint(1,   25),
        'medium'        : lambda: random.randint(25,  100),
        'long'          : lambda: random.randint(100, 500),
        'extreme'       : lambda: random.randint(100, 1000),
    }

def generate_requests(conf, task_rw, task_mutex, task_no_reads, scale=1):
    length = CSLENGTH[conf.cslength]
    for res_id in xrange(conf.num_resources):
        #cslen = int(length()*scale)
        cslen1 = int(length())
        cslen2 = int(length())
        (write_accesses, read_accesses) = draw_cs_count_rw(conf)
        write_len = 0
        read_len = 0
        if write_accesses:
            write_len = cslen1
        if read_accesses:
            read_len = cslen2
        mutex_len = max(read_len, write_len)
        if write_accesses or read_accesses:
            task_rw.resmodel[res_id] = ResourceRequirement(res_id, write_accesses, write_len, read_accesses, read_len)
            task_mutex.resmodel[res_id] = ResourceRequirement(res_id, write_accesses+read_accesses, mutex_len, 0, 0)
        if write_accesses:
            task_no_reads.resmodel[res_id] = ResourceRequirement(res_id, write_accesses, write_len, 0, 0)

def get_overhead_len(cslen, overhead):
    if cslen == 0:
        return 0
    return cslen+overhead

def generate_requests_overhead(conf, ts_dict, task_num):
    length = CSLENGTH[conf.cslength]
    for res_id in xrange(conf.num_resources):
        cslen1 = int(length())
        cslen2 = int(length())
        (write_accesses, read_accesses) = draw_cs_count_rw(conf)
    #    print (write_accesses, read_accesses)
        write_len = 0
        read_len = 0
        if write_accesses:
            write_len = cslen1
        if read_accesses:
            read_len = cslen2
        if write_accesses or read_accesses:
            for ts_name in ts_dict:
                taskset = ts_dict[ts_name]
                taskset[task_num].resmodel[res_id] = ResourceRequirement(res_id, write_accesses, get_overhead_len(write_len, WRITE_OVERHEAD[ts_name]), read_accesses, get_overhead_len(read_len, READ_OVERHEAD[ts_name]))

# ################### tcount ########################
def generate_task_set(conf, n):
    if MORE_GRANULAR:
        ts = conf.generate(max_tasks=n, time_conversion=ms27s)
    else:
        ts = conf.generate(max_tasks=n, time_conversion=ms2us)
    ts.assign_ids()
    initialize_resource_model(ts)
    locking.assign_edf_preemption_levels(ts)

    ts_rw = ts
    ts_mutex = ts.copy()
    ts_no_reads = ts.copy()

    for task_num in range(len(ts)):
        t_rw = ts_rw[task_num]
        t_mutex = ts_mutex[task_num]
        t_no_reads = ts_no_reads[task_num]
        generate_requests(conf, t_rw, t_mutex, t_no_reads)
        t_rw.partition = 1
        t_mutex.partition = 1
        t_no_reads.partition = 1
        total_cs_rw = sum([t_rw.resmodel[res].max_write_length * t_rw.resmodel[res].max_writes +  t_rw.resmodel[res].max_read_length * t_rw.resmodel[res].max_reads for res in t_rw.resmodel])
        t_rw.cost = max(t_rw.cost, total_cs_rw)
        total_cs_mutex = sum([t_mutex.resmodel[res].max_length * t_mutex.resmodel[res].max_requests for res in t_mutex.resmodel])
        t_mutex.cost = max(t_mutex.cost, total_cs_mutex)
        total_cs_no_reads = sum([t_no_reads.resmodel[res].max_length * t_no_reads.resmodel[res].max_requests for res in t_no_reads.resmodel])
        t_no_reads.cost = max(t_no_reads.cost, total_cs_no_reads)
    #"""
    # pre-partition so that (for now) all tests get the same partitioning
    braindead_partition(conf.num_cpus, ts_rw)
    braindead_partition(conf.num_cpus, ts_mutex)
    braindead_partition(conf.num_cpus, ts_no_reads)

    return (ts_rw, ts_mutex, ts_no_reads)

def generate_task_set_overhead(conf, n):
    if MORE_GRANULAR:
        ts = conf.generate(max_tasks=n, time_conversion=ms27s)
    else:
        ts = conf.generate(max_tasks=n, time_conversion=ms2us)
    ts.assign_ids()
    initialize_resource_model(ts)
    locking.assign_edf_preemption_levels(ts)

    ts_dict = {}
    ts_dict["NOLOCK"] = ts.copy()
    ts_dict["NEW-LP"] = ts.copy()
    ts_dict["PFTL-LP"] = ts.copy()
    ts_dict["NONE-LP"] = ts.copy()
    ts_dict["NEW-inflation"] = ts.copy()
    ts_dict["PFTL-inflation"] = ts.copy()
    ts_dict["NONE-inflation"] = ts.copy()

    for task_num in range(len(ts)):
        generate_requests_overhead(conf, ts_dict, task_num)
        for ts_name in ts_dict:
            taskset = ts_dict[ts_name]
            temp_task = taskset[task_num]
            temp_task.partition = 1
            total_cs = sum([temp_task.resmodel[res].max_write_length * temp_task.resmodel[res].max_writes +  temp_task.resmodel[res].max_read_length * temp_task.resmodel[res].max_reads for res in temp_task.resmodel])
            temp_task.cost = max(temp_task.cost, total_cs)
    for ts_name in ts_dict:
        taskset = ts_dict[ts_name]
        braindead_partition(conf.num_cpus, taskset)

    return ts_dict

def generate_task_case_study(conf, n):
    if MORE_GRANULAR:
        ts = conf.generate(max_tasks=n, time_conversion=ms27s)
    else:
        ts = conf.generate(max_tasks=n, time_conversion=ms2us)
    ts.assign_ids()
    initialize_resource_model(ts)
    locking.assign_edf_preemption_levels(ts)


    ts_dict = {}
    ts_dict["NOLOCK"] = ts.copy()
    ts_dict["PF-T-Overhead"] = ts.copy()
    ts_dict["PF-L-Overhead"] = ts.copy()

    for task_num in range(len(ts)):
        for ts_name in ts_dict:
            taskset = ts_dict[ts_name]
            temp_task = taskset[task_num]
            temp_task.partition = 1
            total_overhead = conf.max_requests * READ_OVERHEAD[ts_name]
            temp_task.cost = temp_task.cost + total_overhead
    for ts_name in ts_dict:
        taskset = ts_dict[ts_name]
        braindead_partition(conf.num_cpus, taskset)

    return ts_dict

# ################### latsens ########################    
# #################################################    
# can define named parameter ranges here...
# #################################################

PERIODS = {
    'uni-200-1000' : uniform_int(200, 1000),
    'uni-10-1000'  : uniform_int( 10, 1000),
    'uni-10-100'   : uniform_int( 10,  100),
    'uni-1-1000'   : uniform_int(  1, 1000),

    'log-uni-200-1000' : log_uniform_int(200, 1000),
    'log-uni-10-1000'  : log_uniform_int( 10, 1000),
    'log-uni-10-100'   : log_uniform_int( 10,  100),
    'log-uni-1-1000'   : log_uniform_int(  1, 1000),
    
    #ranges for EMSDATA task generator
    '1-100'         : (1,100),
    '10-1000'       : (10,1000),
    '1-1000'        : (1,1000),
    '10-100'        : (10,100),
}

UTILIZATIONS = {
    'uni-10-40'    :   uniform(0.1,0.4),
    'uni-50-90'    :   uniform(0.5,0.90),
    'uni-50-75'    :   uniform(0.5,0.75),
    'uni-75-95'    :   uniform(0.75,0.95),
    'uni-90-95'    :   uniform(0.75,0.95),
    'uni-95-99'    :   uniform(0.95,0.99),
}

DEADLINES = {
}

# pull in standard periods
PERIODS.update(gen.NAMED_PERIODS)
UTILIZATIONS.update(gen.NAMED_UTILIZATIONS);
DEADLINES.update(gen.NAMED_DEADLINES)

# ############### CONFIG LOADING ###############

DEFAULT_SAMPLES = 1
UTIL_MULTIPLIER = {
    'uni-10-40'    :   2, #4
    'uni-50-90'    :   2, #1.4
    'uni-50-75'    :   2,
    'uni-75-95'    :   2,
    'uni-90-95'    :   1,
    'uni-95-99'    :   1,
    'exp-light'    :   10,
    'uni-light'    :   20,
    'uni-medium'   :   2, #4
}

def check_std_params(conf):
    # standard parameters
    # set the default value if the parameter is not specified
    
    conf.check('num_cpus',     type=int, min=1)
    conf.check('samples',      type=int, default=DEFAULT_SAMPLES, min=1)
    conf.check('deadlines',    type=one_of(DEADLINES), default='implicit')
    conf.check('utilizations', type=one_of(UTILIZATIONS), default='exp-light')
    conf.check('periods',      type=one_of(PERIODS),   default='uni-1-1000')
    
def check_common_params(conf):
    # common parameters to both the experiments
    conf.check('access_prob',    type=float, min=0)
    conf.check('write_prob',     type=float, min=0)
    conf.check('num_resources',  type=int,   min=1)
    conf.check('max_requests',   type=int,   min=1, default=5)
    conf.check('cslength',       type=one_of(CSLENGTH), default='short')
    conf.check('read_cslength',  type=float, min=0)
    
# ################### tcount ########################
    
def check_tcount_config(conf):
    check_std_params(conf)
    check_common_params(conf)
    
    conf.check('step_size', type=int, min=1, default=conf.num_cpus // 2)
    conf.check('tasks_min', type=int, min=1, default=conf.num_cpus)
    if CASE_STUDY:
        conf.check('tasks_max', type=int, min=1, default=32)
    else:
        conf.check('tasks_max', type=int, min=1, default=conf.num_cpus * UTIL_MULTIPLIER[conf.utilizations])
   
    
def run_tcount_config(conf):
    check_tcount_config(conf)

    conf.generate = gen.mkgen(UTILIZATIONS[conf.utilizations],
                              PERIODS[conf.periods],
                              gen.NAMED_DEADLINES[conf.deadlines])

    if APPLY_OVERHEAD:
        conf.make_taskset_overhead = partial(generate_task_set_overhead, conf)
    elif CASE_STUDY:
        conf.make_taskset_case_study = partial(generate_task_case_study, conf)
    else:
        conf.make_taskset = partial(generate_task_set, conf)
    (titles, tests) = zip(*setup_tests(conf))

    header = ['TASKS']
    header += titles

    data = run_tcount(conf, tests, titles)
    write_data(conf.output, data, header)

# ################### latsens ########################
# ############### CONFIG GENERATION ###############

CPU_COUNTS = [8]

UTILS = [
    'exp-light'
]

def generate_tcount_configs(options):
    if CASE_STUDY:
        m = []
        for i in range(100,2001,100):
            m.append(i)
        m = [20]+m
        for cpus in CPU_COUNTS:
            for periods in ['log-uni-1-1000']:
                for util in UTILS:
                    for nr in [1]:
                        for pacc in [1.0]:
                            for cs in ['short']:
                                for nreq in m:
                                    for writep in [0]:
                                        for readcs in [1]:
                                            name = 'sd_exp=pedf-lp-tcount__m=%02d__util=%s__per=%s__nr=%d__pacc=%d__cs=%s__nreq=%d__write-perc=%d__read-cs-len=%d' \
                                          % (cpus, util, periods, nr, pacc * 100, cs, nreq, writep * 100, readcs * 100)
 
                                            c = Config()
                                            c.num_cpus = cpus
                                            c.samples = 1000
                                            c.tasks_min = 32
                                            c.utilizations = util
                                            c.periods = periods
                                            c.max_requests = nreq
                                            c.access_prob = pacc
                                            c.num_resources = nr  #possibly set proportional to number of tasks
                                            c.cslength = cs
                                            c.write_prob = writep
                                            c.read_cslength = readcs
                                            c.output_file  = name + '.csv'
                                            yield (name, c)
    else:
        for cpus in CPU_COUNTS:
            for periods in ['log-uni-1-1000','log-uni-10-100']:
                for util in UTILS:
                    for nr in set([cpus/2, cpus, 2*cpus]):
                        for pacc in [0.1, 0.25, 0.5]:
                            for cs in ['short','medium']:
                                for nreq in [1, 5]:
                                    for writep in [0.1,0.25,0.5,0.75,0.9,1.0]:
                                        for readcs in [1]:
                                            name = 'sd_exp=pedf-lp-tcount__m=%02d__util=%s__per=%s__nr=%d__pacc=%d__cs=%s__nreq=%d__write-perc=%d__read-cs-len=%d' \
                                          % (cpus, util, periods, nr, pacc * 100, cs, nreq, writep * 100, readcs * 100)
 
                                            c = Config()
                                            c.num_cpus = cpus
                                            c.samples = 1000
                                            c.tasks_min = 8
                                            c.utilizations = util
                                            c.periods = periods
                                            c.max_requests = nreq
                                            c.access_prob = pacc
                                            c.num_resources = nr
                                            c.cslength = cs
                                            c.write_prob = writep
                                            c.read_cslength = readcs
                                            c.output_file  = name + '.csv'
                                            yield (name, c)


EXPERIMENTS = {
     'pedf-lp/tcount'   : run_tcount_config,
#     'pedf-lp/latsens'  : run_latsens_config,
#     'pedf-lp/asym'     : run_asym_config,
}

CONFIG_GENERATORS = {
     'pedf-lp/tcount'   : generate_tcount_configs,
#     'pedf-lp/latsens'  : generate_latsens_configs,
#     'pedf-lp/asym'     : generate_asym_configs,
}
