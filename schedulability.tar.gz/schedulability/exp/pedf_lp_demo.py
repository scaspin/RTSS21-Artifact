import os
import sys
import time

import random
from random import shuffle
from itertools import izip
from functools import partial
from datetime import datetime
from collections import defaultdict
import math

from toolbox.io import one_of, Config, write_data
from toolbox.sample import value_range
from toolbox.stats import mean

from schedcat.model.tasks import SporadicTask, TaskSystem
from schedcat.model.resources import initialize_resource_model, ResourceRequirement
import schedcat.generator.tasksets as gen
import schedcat.generator.generator_emstada as emstada

import schedcat.locking.bounds as locking
import schedcat.sched.edf as independent_edf

from  schedcat.generator.tasks import uniform_int, log_uniform_int, uniform_choice, uniform

from schedcat.util.time import ms2us

import schedcat.model.serialize as ser

# directory and file name prefix for taskset files
current_taskset_dir    = "/tmp/"
current_taskset_prefix = "pedf_lp_demo_current_taskset"


# ############### ANALYSIS ###############


def independent_edf_test(taskset):
    # Assumes task set has already been partitioned
    # Split by partition
    partitions = defaultdict(TaskSystem)
    for t in taskset:
        partitions[t.partition].append(t)
    #print "No blocking test..."
    # apply QPA to each partition
    for cpu in partitions:
        if not independent_edf.is_schedulable(1, partitions[cpu]):
            # infeasible even without blocking
            return False
    return True

def tl2_test(taskset):
    return locking.tl2_is_schedulable(taskset);
# ############### SCHEDULABILITY TESTS ###############

def setup_tests(conf):
    return [
        ("no blocking", independent_edf_test),
        ("TL2", tl2_test)
    ]

# ###############   HELPER    ###############

def human_print(taskset, max_cpu):
    
    for cpuid in range(0,max_cpu):
        print "CPU #%d" % cpuid
        U = 0
        for t in taskset:
            if(t.partition==cpuid):
                U = U + (t.cost/float(t.period))
                print t
                for resid in range(1, len(t.resmodel)):
                    if t.resmodel[resid].max_requests>0:
                        print "N = %d" % t.resmodel[resid].max_requests
                        print "L = %d" % t.resmodel[resid].max_length
        
        print U
            
# ############### EXPERIMENTS ###############

def run_tcount(conf, tests):
    count = 0

    for n in range(conf.tasks_min, conf.tasks_max + 1, conf.step_size):
        print "[%d @ %s] n:\t%s" % (os.getpid(), datetime.now(), n)

        utils = []
        samples = [[] for _ in tests]

        for sample in xrange(conf.samples):
            taskset = conf.make_taskset(n)

            # flush out taskset to disk for potential post-mortem analysis
            ser.write(taskset, "%s/%s_pid-%d.ts" % \
                (current_taskset_dir, current_taskset_prefix, os.getpid()))

            utils.append(taskset.utilization())
            
            # For every test i...
            for i in xrange(len(tests)):
                # This assumes that the no-blocking test is the first in tests.
                if i == 0: # This is the no-blocking test. We need to run this in any case.
                    samples[i].append(tests[i](taskset))
                else:
                    # This is one of the tests considering potential blocking.
                    # Did the no-blocking test succeed?
                    if samples[0][-1]:
                        # Yes, this taskset is schedulable without blocking, so let's run our
                        # analysis to see whether it's schedulable with blocking.
                        samples[i].append(tests[i](taskset))
                    else:
                        # No, the taskset is not even schedulable without blocking, so it cannot
                        # possibly be schedulable with blocking.
                         samples[i].append(False)

        print '=> min-u:%.2f avg-u:%.2f max-u:%.2f' % (min(utils), sum(utils) / len(utils), max(utils))
        row = []
        for i in xrange(len(tests)):
            row.append(mean(samples[i]))

        yield [n] + ['%.2f' % x for x in row]
  
        
# ############### TASK SET GENERATION ###############

def braindead_partition(num_cpus, taskset):
    # clearly, something smarter would be desirable...
    # standard resource-oblivious heuristics are available in schedcat.mapping
    for i, t in enumerate(taskset):
        t.partition = i % num_cpus

def draw_cs_count(conf):
    if random.random() <= conf.access_prob:
        # access resource
        return random.randint(1, conf.max_requests)
    else:
        return 0

CSLENGTH  = {
    'uni-1-5'       : lambda: random.randint(1,   5), 
    'uni-1-10'      : lambda: random.randint(1,   10), 
    'short'         : lambda: random.randint(1,   25),
    'medium'        : lambda: random.randint(25,  100),
    'long'          : lambda: random.randint(100, 500),
    'extreme'       : lambda: random.randint(100, 1000),
}

def generate_requests(conf, task, scale=1):
    length = CSLENGTH[conf.cslength]
    for res_id in xrange(conf.num_resources):
        num_accesses = draw_cs_count(conf)
        if num_accesses:
            # add writes
            task.resmodel[res_id] = ResourceRequirement(res_id, num_accesses, length()*scale, 0, 0)

# ################### tcount ########################
def generate_task_set(conf, n):
    ts = conf.generate(max_tasks=n, time_conversion=ms2us)
    ts.assign_ids()
    initialize_resource_model(ts)
    locking.assign_edf_preemption_levels(ts)

    for t in ts:
        generate_requests(conf, t)
        t.partition = 1
        cum_cs = sum([t.resmodel[res].max_length * t.resmodel[res].max_requests for res in t.resmodel])
        t.cost = max(t.cost, cum_cs)

    # pre-partition so that (for now) all tests get the same partitioning
    braindead_partition(conf.num_cpus, ts)

    return ts

    
# #################################################    
# can define named parameter ranges here...
# #################################################

PERIODS = {
    'uni-200-1000' : uniform_int(200, 1000),
    'uni-10-1000'  : uniform_int( 10, 1000),
    'uni-10-100'   : uniform_int( 10,  100),
    'uni-1-1000'   : uniform_int(  1, 1000),

    'log-uni-200-1000' : log_uniform_int(200, 1000),
    'log-uni-10-1000'  : log_uniform_int( 10, 1000),
    'log-uni-10-100'   : log_uniform_int( 10,  100),
    'log-uni-1-100'    : log_uniform_int(  1,  100),
    'log-uni-1-1000'   : log_uniform_int(  1, 1000),
    
    #ranges for EMSDATA task generator
    '1-100'         : (1,100),
    '10-1000'       : (10,1000),
    '1-1000'        : (1,1000),
    '10-100'        : (10,100),
}

UTILIZATIONS = {
    'uni-50-90'    :   uniform(0.5,0.90),
    'uni-50-75'    :   uniform(0.5,0.75),
    'uni-75-95'    :   uniform(0.75,0.95),
    'uni-90-95'    :   uniform(0.75,0.95),
    'uni-95-99'    :   uniform(0.95,0.99),
}

DEADLINES = {
}

# pull in standard periods
PERIODS.update(gen.NAMED_PERIODS)
UTILIZATIONS.update(gen.NAMED_UTILIZATIONS);
DEADLINES.update(gen.NAMED_DEADLINES)

# ############### CONFIG LOADING ###############

DEFAULT_SAMPLES = 1

def check_std_params(conf):
    # standard parameters
    # set the default value if the parameter is not specified
    
    conf.check('num_cpus',     type=int, min=1)
    conf.check('samples',      type=int, default=DEFAULT_SAMPLES, min=1)
    conf.check('deadlines',    type=one_of(DEADLINES), default='implicit')
    conf.check('utilizations', type=one_of(UTILIZATIONS), default='exp-light')
    conf.check('periods',      type=one_of(PERIODS),   default='uni-1-1000')
    
def check_common_params(conf):
    # common parameters to both the experiments
    conf.check('access_prob',    type=float, min=0)
    conf.check('num_resources',  type=int,   min=1)
    conf.check('max_requests',   type=int,   min=1, default=5)
    conf.check('cslength',       type=one_of(CSLENGTH), default='short')
    
# ################### tcount ########################
    
def check_tcount_config(conf):
    check_std_params(conf)
    check_common_params(conf)
    
    conf.check('step_size', type=int, min=1, default=conf.num_cpus // 2)
    conf.check('tasks_min', type=int, min=1, default=conf.num_cpus)
    conf.check('tasks_max', type=int, min=1, default=conf.num_cpus * 10)
   
    
def run_tcount_config(conf):
    check_tcount_config(conf)

    conf.generate = gen.mkgen(UTILIZATIONS[conf.utilizations],
                              PERIODS[conf.periods],
                              gen.NAMED_DEADLINES[conf.deadlines])

    conf.make_taskset = partial(generate_task_set, conf)
    (titles, tests) = zip(*setup_tests(conf))

    header = ['TASKS']
    header += titles

    data = run_tcount(conf, tests)
    write_data(conf.output, data, header)

# ################### latsens ########################

# ############### CONFIG GENERATION ###############

CPU_COUNTS = [2, 4]

UTILS = [
    'exp-light',
]

def generate_tcount_configs(options):
    for cpus in CPU_COUNTS:
        for periods in ['log-uni-10-100']:
            for util in UTILS:
                for nr in [cpus/2]:
               	    for pacc in [0.25]:
                        for cs in ['short']:
                            for nreq in [3]:
                               name = 'sd_exp=pedf-lp-demo-tcount__m=%02d__util=%s__per=%s__nr=%d__pacc=%d__cs=%s__nreq=%d' \
                                      % (cpus, util, periods, nr, pacc * 100, cs, nreq)

                               c = Config()
                               c.num_cpus = cpus
                               c.samples = 100
                               c.tasks_min = 10
                               c.utilizations = util
                               c.periods = periods
                               c.max_requests = nreq
                               c.access_prob = pacc
                               c.num_resources = nr
                               c.cslength = cs

                               c.output_file  = name + '.csv'
                               yield (name, c)

EXPERIMENTS = {
     'pedf-lp-demo/tcount'   : run_tcount_config,
}

CONFIG_GENERATORS = {
     'pedf-lp-demo/tcount'   : generate_tcount_configs,
}
