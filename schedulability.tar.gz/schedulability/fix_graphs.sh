#!/bin/bash

timestamp="05_04_2021-20:30:29"
#timestamp=$(date +"%m_%d_%Y-%H:%M:%s")
plot_dir="plots/"$timestamp
conf_dir="confs/"$timestamp
output_dir="output/"$timestamp



# Graph results
python gen_graphs_all.py $output_dir/*csv
echo "Done making graphs" 

# Move results to plot_dir
mkdir $plot_dir 
mv $output_dir/*pdf $plot_dir 
mv $output_dir/*png $plot_dir 
echo "Done moving graphs" 
