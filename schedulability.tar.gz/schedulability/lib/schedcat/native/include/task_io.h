#ifndef TASK_IO_H
#define TASK_IO_H

std::ostream& operator<<(std::ostream &os, const Task &t);

#endif
