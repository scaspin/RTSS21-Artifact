#ifndef QPA_H
#define QPA_H

class QPATest : public SchedulabilityTest
{
 public:
    QPATest(unsigned int num_processors);

    bool is_schedulable(const TaskSet &ts, bool check_preconditions = true);
    
    virtual integral_t get_demand(integral_t interval, const TaskSet &ts);
    virtual integral_t get_max_interval(const TaskSet &ts, const fractional_t& util);
};

#endif
