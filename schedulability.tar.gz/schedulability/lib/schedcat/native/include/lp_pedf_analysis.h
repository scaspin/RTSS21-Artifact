#ifndef LP_PEDF_ANALYSIS_H
#define LP_PEDF_ANALYSIS_H

// ------------------------------------------------------------------
// --------------------[ A N A L Y S I S ]---------------------------
// ------------------------------------------------------------------

class PEDFBlockingAnalysis
{
  public:
    PEDFBlockingAnalysis(const ResourceSharingInfo& _info, unsigned int _cluster);
                         
    bool isSchedulable();
    
  protected:
    virtual unsigned long computeBlockingPDC(unsigned long interval_length) = 0;
    virtual unsigned long computeBlockingAC (unsigned long interval_length) = 0;
    
    virtual unsigned long computeTighterBlockingPDC(unsigned long interval_length,
                                                    unsigned long blk_UB)
    {
        return blk_UB;    
    }
    
    const ResourceSharingInfo& info;
    unsigned int cluster;
    unsigned int maxDeadline, minDeadline;
  
  private:
    
    bool processorDemandCriterion(std::map<int, unsigned int>& nJobs, unsigned long maxTime);
    bool QPA(unsigned long t_LB, unsigned long t_UB);
    bool rawPDC(unsigned long t_LB, unsigned long t_UB);
    unsigned long DBF(unsigned long interval_length);
    unsigned long arrivalCurve(unsigned long interval_length);
    unsigned long lastCheckPointBefore(unsigned long interval_length);
  
};

#endif
