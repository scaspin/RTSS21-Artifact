#ifndef LP_RW_PHASE_FAIR_H
#define LP_RW_PHASE_FAIR_H

// ------------------------------------------------------------------
// --------------------[ V A R    M A P P E R ]----------------------
// ------------------------------------------------------------------

#include "linprog/varmapperbase.h"

class SpinVarMapperRW : public VarMapperBase
{
	enum variable_type_t
	{
		SPIN_BLOCKING_READ          = 0,
		SPIN_BLOCKING_WRITE 	    = 1,	
		ARRIVAL_BLOCKING_READ       = 2,
		ARRIVAL_BLOCKING_WRITE	    = 3,
        	INDICATOR_ARRIVAL_BLOCKING_READ  = 4,
		INDICATOR_ARRIVAL_BLOCKING_WRITE = 5,
        	CANCELLATIONS               = 6,
		SPIN_BLOCKING_READ_TO_READ  = 7,
		SPIN_BLOCKING_READ_TO_WRITE = 8,
		SPIN_BLOCKING_WRITE_TO_READ = 9,
		SPIN_BLOCKING_WRITE_TO_WRITE = 10,
		Y = 11
	};

	union lookup_key_t
	{
		uint64_t raw;
		struct
		{
			uint64_t tid:20; // task ID
			uint64_t rid:20; // resource ID

			uint64_t variable_type:4; 
		} var;

		enum
		{
			KEY_MAX   = (unsigned) (1 << 20),
			VTYPE_MAX = (unsigned)(1 <<  4),
		};

		/* construct an X^{S,A} variable */
		void make_var_for(
			unsigned int task_id, unsigned int res_id,
			variable_type_t btype)
		{
			assert(task_id < KEY_MAX);
			assert(res_id < KEY_MAX);

			raw = 0;
			var.tid = task_id;
			var.rid = res_id;
			var.variable_type = btype;
		}
	};

public:
	unsigned int spin_read(unsigned int task_id, unsigned int res_id)
	{
		lookup_key_t k;

		k.make_var_for(task_id, res_id, SPIN_BLOCKING_READ);
		return var_for_key(k.raw);
	}
	
	unsigned int spin_write(unsigned int task_id, unsigned int res_id)
        {
                lookup_key_t k;

                k.make_var_for(task_id, res_id, SPIN_BLOCKING_WRITE);
                return var_for_key(k.raw);
        }

	unsigned int spin_read_to_read(unsigned int task_id, unsigned int res_id)
        {
                lookup_key_t k;

                k.make_var_for(task_id, res_id, SPIN_BLOCKING_READ_TO_READ);
                return var_for_key(k.raw);
        }
	unsigned int spin_read_to_write(unsigned int task_id, unsigned int res_id)
        {
                lookup_key_t k;

                k.make_var_for(task_id, res_id, SPIN_BLOCKING_READ_TO_WRITE);
                return var_for_key(k.raw);
        }
	unsigned int spin_write_to_read(unsigned int task_id, unsigned int res_id)
        {
                lookup_key_t k;

                k.make_var_for(task_id, res_id, SPIN_BLOCKING_WRITE_TO_READ);
                return var_for_key(k.raw);
        }
	unsigned int spin_write_to_write(unsigned int task_id, unsigned int res_id)
        {
                lookup_key_t k;

                k.make_var_for(task_id, res_id, SPIN_BLOCKING_WRITE_TO_WRITE);
                return var_for_key(k.raw);
        }

	unsigned int arrival_read(unsigned int task_id, unsigned int res_id)
	{
		lookup_key_t k;

		k.make_var_for(task_id, res_id, ARRIVAL_BLOCKING_READ);
		return var_for_key(k.raw);
	}

	unsigned int arrival_write(unsigned int task_id, unsigned int res_id)
        {
                lookup_key_t k;

                k.make_var_for(task_id, res_id, ARRIVAL_BLOCKING_WRITE);
                return var_for_key(k.raw);
        }
    
    	unsigned int indicator_arrival_read(unsigned int res_id)
	{
		lookup_key_t k;

		k.make_var_for(0, res_id, INDICATOR_ARRIVAL_BLOCKING_READ);
		return var_for_key(k.raw);
	}
	unsigned int indicator_arrival_write(unsigned int res_id)
        {
                lookup_key_t k;

                k.make_var_for(0, res_id, INDICATOR_ARRIVAL_BLOCKING_WRITE);
                return var_for_key(k.raw);
        }
    
        unsigned int cancellations(unsigned int task_id, unsigned int res_id)
	{
		lookup_key_t k;

		k.make_var_for(task_id, res_id, CANCELLATIONS);
		return var_for_key(k.raw);
	}


	unsigned int bin_y(unsigned int constraint, unsigned int res_id)
        {
                lookup_key_t k;
                k.make_var_for(constraint, res_id, Y); //uses first field for constraint number 21-23 instead of for task id
                return var_for_key(k.raw);
        }

	std::string key2str(uint64_t key, unsigned int var) const;
};

// ------------------------------------------------------------------
// -----------------------------[ L P ]------------------------------
// ------------------------------------------------------------------


enum analysis_type_t
{
    AC_MODE, // compute LP for an arrival curve
    PDC_MODE // compute processor-demand criterion LP
};


class PEDFBlockingAnalysisLP_Spinlocks_RW : protected LinearProgram
{
    
protected:

	SpinVarMapperRW vars;
	const TaskInfos& taskset;
    
    	const ResourceSharingInfo& info;

	// which type of LP are we constructing?
	const analysis_type_t lp_type;

	// length of the analysis interval
	const unsigned long interval_length;
    
    	// cluster under analysis
    	unsigned int cluster;

	const std::set<unsigned int> all_resources;

	// Hack that may be needed in derived classes if some
	// constraints need to reference member fields that are not yet initialized
	// during object construction.
	//virtual void add_constraints_post_ctor() {};

private:

	void set_objective();

	// Generic constraints: constraints that hold under any locking protocol...
    	
    	void read_add_no_arrival_blocking_dline_inside_interval();
    	void write_add_no_arrival_blocking_dline_inside_interval();
	void read_add_no_spin_delay_local_requests();
	void write_add_no_spin_delay_local_requests();
	void read_add_joint_upper_bound_remote_requests();
    	void write_add_joint_upper_bound_remote_requests();
	void add_no_arrival_blocking_for_local_req_not_in_pc();
	void add_upper_bound_on_read_arrival_blocking_by_number_of_requests();
	void add_upper_bound_on_write_arrival_blocking_by_number_of_requests();
	void add_upper_bound_on_read_arrival_blocking();
	void add_upper_bound_on_write_arrival_blocking();

    	void add_no_arrival_blocking();
        void add_upper_bound_on_arrival_blocking();
public:
	typedef const unsigned int var_t;

	PEDFBlockingAnalysisLP_Spinlocks_RW(
		const ResourceSharingInfo& info,
		analysis_type_t analysis_type,
		unsigned long interval_length,
        	unsigned int cluster);

	unsigned long solve(bool verbose = false);
};

#endif
