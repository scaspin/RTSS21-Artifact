#include <stdint.h>
#include <cassert>
#include <cmath>
#include <climits>

#include "linprog/model.h"
#include "linprog/varmapperbase.h"
#include "linprog/solver.h"

#include "sharedres_types.h"

#include "iter-helper.h"
#include "stl-helper.h"
#include "stl-io-helper.h"

#include <iostream>
#include <sstream>
#include "res_io.h"
#include "linprog/io.h"

#include "lp_rw_phase_fair_common.h"
#include "lp_pedf_analysis.h"


class RW_PFAIR_LP : public PEDFBlockingAnalysisLP_Spinlocks_RW
{
private:

	void add_at_max_one_write_delay_per_read_request();
        void add_at_max_one_write_delay_per_write_request();
        void set_equal_read_or_write_for_write_spin_delay();
	void add_at_max_one_read_delay_per_read_request();
	void add_write_execution_delay_per_read_request();
        void add_constraint_on_remote_reads_per_write_request();
	void set_qual_read_or_write_delay_for_read_spin_delay();
	void add_per_task_write_by_write_spin_delay();
	void add_per_task_read_by_write_spin_delay();
	void add_per_task_read_by_read_spin_delay();
	void add_limit_of_one_read_causing_arrival_blocking_on_remotely();
	void add_upper_bound_on_read_arrival_blocking_by_write_arrival_blocking();
	void add_no_remote_requests_causing_arrival_blocking_if_no_request_for_resource_can();
	void add_bound_on_number_of_write_requests_responsible_for_arrival_blocking();
	void constraint25();
	void constraint26();
        void add_bound_on_reads_by_writes_based_on_read_arrival_blocking();

public:
	RW_PFAIR_LP(const ResourceSharingInfo& info,
			analysis_type_t analysis_type,
			unsigned long interval_length,
            unsigned int cluster)
		: PEDFBlockingAnalysisLP_Spinlocks_RW(info, analysis_type, interval_length, cluster)
	{

	add_at_max_one_write_delay_per_read_request();
	add_at_max_one_write_delay_per_write_request();
        set_equal_read_or_write_for_write_spin_delay();
	add_at_max_one_read_delay_per_read_request();
        add_write_execution_delay_per_read_request();
        add_constraint_on_remote_reads_per_write_request();
        set_qual_read_or_write_delay_for_read_spin_delay();
	add_per_task_write_by_write_spin_delay();
	add_per_task_read_by_write_spin_delay();
        add_per_task_read_by_read_spin_delay();
	add_limit_of_one_read_causing_arrival_blocking_on_remotely();
        add_upper_bound_on_read_arrival_blocking_by_write_arrival_blocking();
        add_no_remote_requests_causing_arrival_blocking_if_no_request_for_resource_can();
    //    add_bound_on_number_of_write_requests_responsible_for_arrival_blocking();

	constraint25();
	constraint26();
        add_bound_on_reads_by_writes_based_on_read_arrival_blocking();

        vars.seal(); // every possible variable should have been referenced
	}
};


// ------------------------------------------------------------------
// --------------------[C O N S T R A I N T S]-----------------------
// ------------------------------------------------------------------

void RW_PFAIR_LP::add_at_max_one_write_delay_per_read_request()
{
   foreach(all_resources,q_iter)
   {
       LinearExpression *LHS = new LinearExpression();
       const unsigned int q = *q_iter;

       // For each processor k, different from the one under observation
	foreach_cluster_except(info, cluster, k)    //swapped the two foreach loops and pulled out the definition of LHS and q
       	{
           // For each task T_x in processor k
           foreach_task_in_cluster(info.get_tasks(), k, T_x)
           {
               const unsigned int x = T_x->get_id();
               var_t X_SPIN_WRITE_to_READ = vars.spin_write_to_read(x, q); 
               LHS->add_var(X_SPIN_WRITE_to_READ);
           }

       }

       unsigned long RHS = 0;    //<- I pulled RHS out of the above loop

       // For each task T_i in the processor under observation
       foreach_task_in_cluster(info.get_tasks(), cluster, T_i)     // moved this (and the following) out of the foreach_cluster_except loop
       {
           unsigned long njobs = 0;

           if(lp_type==PDC_MODE)
               njobs = T_i->get_pedf_PDC_max_num_local_jobs(interval_length);
           if(lp_type==AC_MODE)
               njobs = T_i->get_pedf_AC_max_num_local_jobs(interval_length);

           RHS += njobs*T_i->get_num_read_requests(q);
       }
       add_inequality(LHS,RHS);
   }

}

void RW_PFAIR_LP::add_at_max_one_write_delay_per_write_request(){
   // For each processor k, different from the one under observation
   foreach_cluster_except(info, cluster, k)
   {
       foreach(all_resources,q_iter)
       {
           const unsigned int q = *q_iter;
          
           LinearExpression *LHS = new LinearExpression();
           unsigned long RHS = 0;
          
           // For each task T_x in processor k
           foreach_task_in_cluster(info.get_tasks(), k, T_x)
           {
               const unsigned int x = T_x->get_id();
               var_t X_SPIN_WRITE_to_WRITE  = vars.spin_write_to_write(x, q);
               LHS->add_var(X_SPIN_WRITE_to_WRITE);
           }
          
           // For each task T_i in the processor under observation
           foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
           {
               unsigned long njobs = 0;
              
               if(lp_type==PDC_MODE)
                   njobs = T_i->get_pedf_PDC_max_num_local_jobs(interval_length);
               if(lp_type==AC_MODE)
                   njobs = T_i->get_pedf_AC_max_num_local_jobs(interval_length);
              
               RHS += njobs*T_i->get_num_write_requests(q);
           }
          
           add_inequality(LHS,RHS);
       }
   }

}

//modified this so instead of X_SPIN_WRITE = X_SPIN_Write_to_write + X_SPIN_Write_to_read we have
// X_SPIN_WRITE_to_write + X_SPIN_write_to_read - X_SPIN_write = 0
void RW_PFAIR_LP::set_equal_read_or_write_for_write_spin_delay(){
   foreach_cluster_except(info, cluster, k)
   {
       foreach(all_resources,q_iter)
       {
           const unsigned int q = *q_iter;

	   // For each task T_x in processor k
           foreach_task_in_cluster(info.get_tasks(), k, T_x)
           {
               	const unsigned int x = T_x->get_id();

           	LinearExpression *exp = new LinearExpression();
          	var_t X_SPIN_WRITE  = vars.spin_write(x, q);
           	var_t X_SPIN_WRITE_TO_READ = vars.spin_write_to_read(x,q);
	        var_t X_SPIN_WRITE_TO_WRITE = vars.spin_write_to_write(x,q);
           
	   	exp->add_var(X_SPIN_WRITE_TO_READ);
	   	exp->add_var(X_SPIN_WRITE_TO_WRITE);
	   	exp->sub_var(X_SPIN_WRITE);

           	add_equality(exp,0);
	   }
       }
   }
}

void RW_PFAIR_LP::add_at_max_one_read_delay_per_read_request(){
   foreach(all_resources,q_iter)
   {
       LinearExpression *LHS = new LinearExpression();
       const unsigned int q = *q_iter;

       // For each processor k, different from the one under observation
        foreach_cluster_except(info, cluster, k)   
       {
           // For each task T_x in processor k
           foreach_task_in_cluster(info.get_tasks(), k, T_x)
           {
               const unsigned int x = T_x->get_id();
               var_t X_SPIN_READ_TO_READ = vars.spin_read_to_read(x, q); 
               LHS->add_var(X_SPIN_READ_TO_READ);
           }

       }

       unsigned long RHS = 0;   

       // For each task T_i in the processor under observation
       foreach_task_in_cluster(info.get_tasks(), cluster, T_i)   
       {
           unsigned long njobs = 0;

           if(lp_type==PDC_MODE)
               njobs = T_i->get_pedf_PDC_max_num_local_jobs(interval_length);
           if(lp_type==AC_MODE)
               njobs = T_i->get_pedf_AC_max_num_local_jobs(interval_length);

           RHS += njobs*T_i->get_num_read_requests(q);
       }
       add_inequality(LHS,RHS);
   }

}

void RW_PFAIR_LP::add_write_execution_delay_per_read_request(){
    foreach(all_resources,q_iter)
    {
	 LinearExpression *exp = new LinearExpression();
       	 const unsigned int q = *q_iter;

	 // For each processor k, different from the one under observation
        foreach_cluster_except(info, cluster, k)
        {
           // For each task T_x in processor k
           foreach_task_in_cluster(info.get_tasks(), k, T_x)
           {
               const unsigned int x = T_x->get_id();
	       var_t X_SPIN_READ_TO_READ = vars.spin_read_to_read(x, q);
               var_t X_SPIN_WRITE_TO_READ = vars.spin_write_to_read(x,q);

	       exp->add_var(X_SPIN_READ_TO_READ);
	       exp->sub_var(X_SPIN_WRITE_TO_READ);
           }

        }

    	add_inequality(exp, 0);
    }
}

void RW_PFAIR_LP::add_constraint_on_remote_reads_per_write_request(){
    foreach(all_resources,q_iter)
    {
         LinearExpression *exp = new LinearExpression();
         const unsigned int q = *q_iter;

         // For each processor k, different from the one under observation
        foreach_cluster_except(info, cluster, k)
        {
           // For each task T_x in processor k
           foreach_task_in_cluster(info.get_tasks(), k, T_x)
           {
               const unsigned int x = T_x->get_id();
               var_t X_SPIN_READ_TO_WRITE = vars.spin_read_to_write(x, q);
               var_t X_SPIN_WRITE_TO_WRITE = vars.spin_write_to_write(x,q);

               exp->add_var(X_SPIN_READ_TO_WRITE);
               exp->sub_var(X_SPIN_WRITE_TO_WRITE);
           }

        }

        // Compute sum of nljobs * N^w for tasks on pstar
        unsigned long RHS = 0;
        foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        {
            unsigned long nljobs = 0;

             if(lp_type==PDC_MODE)
                 nljobs = T_i->get_pedf_PDC_max_num_local_jobs(interval_length);
             if(lp_type==AC_MODE)
                 nljobs = T_i->get_pedf_AC_max_num_local_jobs(interval_length);

             RHS += nljobs*T_i->get_num_write_requests(q);
        }
        add_inequality(exp, RHS);
    }
}

void RW_PFAIR_LP::set_qual_read_or_write_delay_for_read_spin_delay(){
   foreach_cluster_except(info, cluster, k)
   {
       foreach(all_resources,q_iter)
       {
           const unsigned int q = *q_iter;

           // For each task T_x in processor k
           foreach_task_in_cluster(info.get_tasks(), k, T_x)
           {
                const unsigned int x = T_x->get_id();

                LinearExpression *exp = new LinearExpression();
                var_t X_SPIN_READ  = vars.spin_read(x, q);
                var_t X_SPIN_READ_TO_READ = vars.spin_read_to_read(x,q);
                var_t X_SPIN_READ_TO_WRITE = vars.spin_read_to_write(x,q);

                exp->add_var(X_SPIN_READ_TO_READ);
                exp->add_var(X_SPIN_READ_TO_WRITE);
                exp->sub_var(X_SPIN_READ);

                add_equality(exp,0);
           }
       }
   }
}

void RW_PFAIR_LP::add_per_task_write_by_write_spin_delay()
{
    foreach_task_not_in_cluster(info.get_tasks(), cluster, T_x)
    {
        foreach(all_resources,q_iter)
        {
            const unsigned int q = *q_iter;

            unsigned long RHS = 0;
            const unsigned int x = T_x->get_id();
            
	    LinearExpression *exp = new LinearExpression();
	    var_t X_SPIN_WRITE_TO_WRITE = vars.spin_write_to_write(x, q);
	    exp->add_var(X_SPIN_WRITE_TO_WRITE);

            foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
            {
                const unsigned long nrjobs_T_i = T_i->get_pedf_max_num_remote_jobs(T_x->get_deadline());
                const unsigned long nrjobs_T_x = T_x->get_pedf_max_num_remote_jobs(interval_length);

                RHS += nrjobs_T_i * T_i->get_num_write_requests(q) * nrjobs_T_x;
            }

            add_inequality(exp,RHS);
        }
    }
}

void RW_PFAIR_LP::add_per_task_read_by_write_spin_delay()
{
    foreach_task_not_in_cluster(info.get_tasks(), cluster, T_x)
    {
        foreach(all_resources,q_iter)
        {
            const unsigned int q = *q_iter;

            unsigned long RHS = 0;
            const unsigned int x = T_x->get_id();

            LinearExpression *exp = new LinearExpression();
            var_t X_SPIN_WRITE_TO_READ = vars.spin_write_to_read(x, q);
            exp->add_var(X_SPIN_WRITE_TO_READ);

            foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
            {
                const unsigned long nrjobs_T_i = T_i->get_pedf_max_num_remote_jobs(T_x->get_deadline());
                const unsigned long nrjobs_T_x = T_x->get_pedf_max_num_remote_jobs(interval_length);

                RHS += nrjobs_T_i * T_i->get_num_read_requests(q) * nrjobs_T_x;
            }

            add_inequality(exp,RHS);
        }
    }

}

void RW_PFAIR_LP::add_per_task_read_by_read_spin_delay()
{
    foreach_task_not_in_cluster(info.get_tasks(), cluster, T_x)
    {
        foreach(all_resources,q_iter)
        {
            const unsigned int q = *q_iter;

            unsigned long RHS = 0;
            const unsigned int x = T_x->get_id();

            LinearExpression *exp = new LinearExpression();
            var_t X_SPIN_READ_TO_READ = vars.spin_read_to_read(x, q);
            exp->add_var(X_SPIN_READ_TO_READ);

            foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
            {
                const unsigned long nrjobs_T_i = T_i->get_pedf_max_num_remote_jobs(T_x->get_deadline());
                const unsigned long nrjobs_T_x = T_x->get_pedf_max_num_remote_jobs(interval_length);

                RHS += nrjobs_T_i * T_i->get_num_read_requests(q) * nrjobs_T_x;
            }

            add_inequality(exp,RHS);
        }
    }
}

// Big M Arrival Constraints 
void RW_PFAIR_LP::add_limit_of_one_read_causing_arrival_blocking_on_remotely()
{
	foreach(all_resources,q_iter)
    	{
		const unsigned int q = *q_iter;

		//constraint 1
		LinearExpression *exp1 = new LinearExpression();
 	        var_t X_Y = vars.bin_y(21, q);
		var_t X_INDICATOR_ARRIVAL_READ = vars.indicator_arrival_read(q);
		
		declare_variable_binary(X_INDICATOR_ARRIVAL_READ);
		declare_variable_binary(X_Y);

		exp1->add_var(X_INDICATOR_ARRIVAL_READ);
		exp1->sub_var(X_Y);
		add_inequality(exp1, 0);

		//constraints 2
		LinearExpression *exp2 = new LinearExpression();
		unsigned int M = 0;

        	// For each processor k, different from the one under observation
        	foreach_cluster_except(info, cluster, k)
        	{
           	// For each task T_x in processor k
           	    foreach_task_in_cluster(info.get_tasks(), k, T_x)
           	    {
               		const unsigned int x = T_x->get_id();
               		var_t X_ARRIVAL_READ = vars.arrival_read(x,q);
               		//add values of double summation
			exp2->add_var(X_ARRIVAL_READ);
           	    
			unsigned int nrjobs =  T_x->get_pedf_max_num_remote_jobs(interval_length);
		        M += nrjobs * T_x->get_num_read_requests(q);
		    }
        	}
		//exp2->sub_var(M*(1-X_Y));
		//simplified this to just regular variables:
		exp2->add_term(M, X_Y);

		const unsigned int RHS = M + 1;
		add_inequality(exp2, RHS);

    	}
}


void RW_PFAIR_LP::add_upper_bound_on_read_arrival_blocking_by_write_arrival_blocking()
{
	foreach(all_resources,q_iter)
        {
                const unsigned int q = *q_iter;

                //constraint 1
                LinearExpression *exp1 = new LinearExpression();
                var_t X_Y = vars.bin_y(22,q);
                var_t X_INDICATOR_ARRIVAL_WRITE = vars.indicator_arrival_write(q);
                
		declare_variable_binary(X_INDICATOR_ARRIVAL_WRITE);
                declare_variable_binary(X_Y);
		
		exp1->add_var(X_INDICATOR_ARRIVAL_WRITE);
                exp1->sub_var(X_Y);
                add_inequality(exp1, 0);

                //constraints 2
                LinearExpression *exp2 = new LinearExpression();
                unsigned int M = 0;

                // For each processor k, different from the one under observation
                foreach_cluster_except(info, cluster, k)
                {
                // For each task T_x in processor k
                    foreach_task_in_cluster(info.get_tasks(), k, T_x)
                    {
                        const unsigned int x = T_x->get_id();
                        var_t X_ARRIVAL_READ = vars.arrival_read(x,q);
                        var_t X_ARRIVAL_WRITE = vars.arrival_write(x,q);
			//add values of double summation
                        exp2->add_var(X_ARRIVAL_READ);
			exp2->sub_var(X_ARRIVAL_WRITE); 

                        unsigned int nrjobs =  T_x->get_pedf_max_num_remote_jobs(interval_length);
                        M += nrjobs * T_x->get_num_read_requests(q);
                    }
                }
                //exp2->sub_var(M*(1-X_Y));
                exp2->add_term(M, X_Y);
		
		const unsigned int RHS = M + 1;
		add_inequality(exp2, RHS);
        }
}

void RW_PFAIR_LP::add_no_remote_requests_causing_arrival_blocking_if_no_request_for_resource_can()
{
	foreach(all_resources,q_iter)
        {
                const unsigned int q = *q_iter;

                //constraint 1
                LinearExpression *exp1 = new LinearExpression();
                var_t X_Y = vars.bin_y(23,q);
                var_t X_INDICATOR_ARRIVAL_READ = vars.indicator_arrival_read(q);
		var_t X_INDICATOR_ARRIVAL_WRITE = vars.indicator_arrival_write(q);
                
		declare_variable_binary(X_INDICATOR_ARRIVAL_READ);
                declare_variable_binary(X_INDICATOR_ARRIVAL_WRITE);
		declare_variable_binary(X_Y);

		exp1->sub_var(X_INDICATOR_ARRIVAL_READ);
		exp1->sub_var(X_INDICATOR_ARRIVAL_WRITE);
                exp1->sub_var(X_Y);
                add_inequality(exp1, -1);

                //constraints 2
                LinearExpression *exp2 = new LinearExpression();
                unsigned int M = 0;

                // For each processor k, different from the one under observation
                foreach_cluster_except(info, cluster, k)
                {
                // For each task T_x in processor k
                    foreach_task_in_cluster(info.get_tasks(), k, T_x)
                    {
                        const unsigned int x = T_x->get_id();
                        var_t X_ARRIVAL_READ = vars.arrival_read(x,q);
                        var_t X_ARRIVAL_WRITE = vars.arrival_write(x,q);
                        //add values of double summation
                        exp2->add_var(X_ARRIVAL_READ);
                        exp2->add_var(X_ARRIVAL_WRITE); 

                        unsigned int nrjobs =  T_x->get_pedf_max_num_remote_jobs(interval_length);
                        M += nrjobs * (T_x->get_num_read_requests(q) + T_x->get_num_write_requests(q));
                    }
                }
                //exp2->sub_var(M*(1-X_Y));
                exp2->add_term(M, X_Y);
		
		add_inequality(exp2, M);
        }
}

void RW_PFAIR_LP::add_bound_on_number_of_write_requests_responsible_for_arrival_blocking()
{
	foreach(all_resources,q_iter)
        {
		const unsigned int q = *q_iter;

		LinearExpression *exp = new LinearExpression();
		var_t X_INDICATOR_ARRIVAL_READ = vars.indicator_arrival_read(q);
                var_t X_INDICATOR_ARRIVAL_WRITE = vars.indicator_arrival_write(q);
		
		declare_variable_binary(X_INDICATOR_ARRIVAL_READ);
		declare_variable_binary(X_INDICATOR_ARRIVAL_WRITE);
		
		exp->sub_var(X_INDICATOR_ARRIVAL_READ);
                exp->sub_var(X_INDICATOR_ARRIVAL_WRITE);

		foreach_cluster_except(info, cluster, k)
        	{
			foreach_task_in_cluster(info.get_tasks(), k, T_x)
			{
				const unsigned int x = T_x->get_id();
                        	var_t X_ARRIVAL_WRITE = vars.arrival_write(x,q);
				exp->add_var(X_ARRIVAL_WRITE);
			}	
		}
		add_inequality(exp, 0);
	}

}

void RW_PFAIR_LP::constraint25()
{
	foreach(all_resources,q_iter)
        {
                const unsigned int q = *q_iter;

                //constraint 1
                LinearExpression *exp1 = new LinearExpression();
                var_t X_Y = vars.bin_y(25,q);
		var_t X_INDICATOR_ARRIVAL_READ = vars.indicator_arrival_read(q);
		
		declare_variable_binary(X_INDICATOR_ARRIVAL_READ);

		exp1->add_var(X_INDICATOR_ARRIVAL_READ);
		exp1->sub_var(X_Y);
		add_inequality(exp1, 0);

		//constraint 2
		LinearExpression *exp2 = new LinearExpression();
                unsigned int M = 0;

                // For each processor k, different from the one under observation
                foreach_cluster_except(info, cluster, k)
                {
                // For each task T_x in processor k
                    foreach_task_in_cluster(info.get_tasks(), k, T_x)
                    {
                        const unsigned int x = T_x->get_id();
                        var_t X_ARRIVAL_WRITE = vars.arrival_write(x,q);
                        
			exp2->add_var(X_ARRIVAL_WRITE);

                        unsigned int nrjobs =  T_x->get_pedf_max_num_remote_jobs(interval_length);
                        M += nrjobs * (T_x->get_num_write_requests(q));
                    }
                }

                exp2->add_term(M, X_Y);
		M++;
                add_inequality(exp2, M);
	}
}

void RW_PFAIR_LP::constraint26()
{
        foreach(all_resources,q_iter)
        {
                const unsigned int q = *q_iter;

                //constraint 1
                LinearExpression *exp1 = new LinearExpression();
                var_t X_Y = vars.bin_y(26,q);
                var_t X_INDICATOR_ARRIVAL_WRITE = vars.indicator_arrival_write(q);

                declare_variable_binary(X_INDICATOR_ARRIVAL_WRITE);

                exp1->add_var(X_INDICATOR_ARRIVAL_WRITE);
                exp1->sub_var(X_Y);
                add_inequality(exp1, 0);

                //constraint 2
                unsigned int M = 0;

                // For each task not in this cluster, compute contribution to M
                foreach_task_not_in_cluster(info.get_tasks(), cluster, T_x)
                {
                    unsigned int nrjobs =  T_x->get_pedf_max_num_remote_jobs(interval_length);
                    M += nrjobs * (T_x->get_num_write_requests(q));
                }
                unsigned int M_1 = M + 1;

                // For each processor k, different from the one under observation
                foreach_cluster_except(info, cluster, k)
                {
                    LinearExpression *exp2 = new LinearExpression();

                    // For each task T_x in processor k
                    foreach_task_in_cluster(info.get_tasks(), k, T_x)
                    {
                        const unsigned int x = T_x->get_id();
                        var_t X_ARRIVAL_WRITE = vars.arrival_write(x,q);

                        exp2->add_var(X_ARRIVAL_WRITE);
                    }
                
                    exp2->add_term(M, X_Y);
                    add_inequality(exp2, M_1);
                }
        }
}

void RW_PFAIR_LP::add_bound_on_reads_by_writes_based_on_read_arrival_blocking()
{
	foreach(all_resources,q_iter)
        {
		const unsigned int q = *q_iter;

		//constraint 1
		LinearExpression *exp1 = new LinearExpression();
                var_t X_Y = vars.bin_y(27, q);
                var_t X_INDICATOR_ARRIVAL_READ = vars.indicator_arrival_read(q);

                declare_variable_binary(X_INDICATOR_ARRIVAL_READ);
                declare_variable_binary(X_Y);

                exp1->add_var(X_INDICATOR_ARRIVAL_READ);
                exp1->sub_var(X_Y);
                add_inequality(exp1, 0);

                //constraint 2
                LinearExpression *exp2 = new LinearExpression();
                unsigned int M = 0;

                // For each processor k, different from the one under observation
                foreach_cluster_except(info, cluster, k)
                {
                    // For each task T_x in processor k
                    foreach_task_in_cluster(info.get_tasks(), k, T_x)
                    {
                        const unsigned int x = T_x->get_id();
                        var_t X_ARRIVAL_READ = vars.arrival_read(x,q);
                        var_t X_ARRIVAL_WRITE = vars.arrival_write(x,q);
                        //add values of double summation
                        exp2->add_var(X_ARRIVAL_READ);
                        exp2->sub_var(X_ARRIVAL_WRITE);

                        unsigned int nrjobs =  T_x->get_pedf_max_num_remote_jobs(interval_length);
                        M += nrjobs * T_x->get_num_read_requests(q);
		    }
                }
                //exp2->sub_var(M*(1-X_Y));
                //simplified this to just regular variables:
                exp2->add_term(M, X_Y);

                add_inequality(exp2, M);

        }
}



// ------------------------------------------------------------------
// -----------[B L O C K I N G   M E T H O D S ]---------------------
// ------------------------------------------------------------------


class PEDFBlockingAnalysisRWPFair : public PEDFBlockingAnalysis
{
    
private:
    unsigned long computeBlockingPDC(unsigned long interval_length);
    unsigned long computeBlockingAC (unsigned long interval_length);
    
public:
    PEDFBlockingAnalysisRWPFair(const ResourceSharingInfo& info, unsigned int cluster) : PEDFBlockingAnalysis(info, cluster) {}

};

unsigned long PEDFBlockingAnalysisRWPFair::computeBlockingPDC(unsigned long interval_length)
{
    RW_PFAIR_LP mip(info, PDC_MODE, interval_length, cluster);
	
    return mip.solve(false);
}
unsigned long PEDFBlockingAnalysisRWPFair::computeBlockingAC (unsigned long interval_length)
{
    RW_PFAIR_LP mip(info, AC_MODE, interval_length, cluster);
	
    return mip.solve(false);
}

// ------------------------------------------------------------------
// --------------------[ E N T R Y    P O I N T ]--------------------
// ------------------------------------------------------------------

bool rw_phase_fair_is_schedulable(const ResourceSharingInfo& info)
{
    foreach_cluster(info, k)
    {	
        // Perform schedulability analysis for each processor k
        PEDFBlockingAnalysisRWPFair analysis(info, k);
        if(!analysis.isSchedulable()) return false;
    }
    
    return true;
}
