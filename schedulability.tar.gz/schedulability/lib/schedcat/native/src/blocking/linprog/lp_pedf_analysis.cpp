#include <stdint.h>
#include <cassert>
#include <climits>
#include <cmath>

#include "linprog/varmapperbase.h"
#include "linprog/solver.h"

#include "sharedres_types.h"

#include "iter-helper.h"
#include "stl-helper.h"
#include "stl-io-helper.h"
#include "math-helper.h"

#include <iostream>
#include <sstream>
#include "res_io.h"
#include "linprog/io.h"

#include "lp_pedf_analysis.h"

// ------------------------------------------------------------------
// --------------------[ A N A L Y S I S ]---------------------------
// ------------------------------------------------------------------

//#define __DEBUG_PEDF_BLK_ANALYSIS__

unsigned long gcd(unsigned long a, unsigned long b)
{
    while(true)
    {
        if (a == 0) return b;
        b %= a;
        if (b == 0) return a;
        a %= b;
    }
}

unsigned long lcm(unsigned long a, unsigned long b)
{
    unsigned long temp = gcd(a, b);
    return temp ? (a / temp * b) : 0;
}

PEDFBlockingAnalysis::PEDFBlockingAnalysis(const ResourceSharingInfo& _info, unsigned int _cluster) :
info(_info), cluster(_cluster)
{
    maxDeadline = 0;
    
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        maxDeadline = (maxDeadline > T_i->get_deadline() ? maxDeadline : T_i->get_deadline());
        
    minDeadline = maxDeadline;
    
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        minDeadline = (T_i->get_deadline() < minDeadline ? T_i->get_deadline() : minDeadline);
}

unsigned long PEDFBlockingAnalysis::DBF(unsigned long interval_length)
{
    unsigned long retval = 0;
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        retval += T_i->get_pedf_PDC_max_num_local_jobs(interval_length)*T_i->get_cost();
    
    return retval;
}

unsigned long PEDFBlockingAnalysis::arrivalCurve(unsigned long interval_length)
{
    unsigned long retval = 0;
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        retval += T_i->get_pedf_AC_max_num_local_jobs(interval_length)*T_i->get_cost();
    
    return retval;
}

bool PEDFBlockingAnalysis::isSchedulable()
{
    
	unsigned long lastBW_Len = 1;
    unsigned long hyper_period = 1;
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
    {
        hyper_period = lcm(hyper_period,T_i->get_period());
    }
    
    #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
    std::cout << "#Hyper-period = " << hyper_period << std::endl;
    #endif
    
    // Perform PDC until the first idle-time
	while(true)
	{
		// Fixed-point iteration step
        unsigned long newBW_Len = arrivalCurve(lastBW_Len) + computeBlockingAC(lastBW_Len);
        
        #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
		std::cout << "#ARRCRV Update : lastBW_Len = " << lastBW_Len << ", newBW_Len=" << newBW_Len << std::endl;
        #endif
        
		if(newBW_Len == lastBW_Len)     break;
        
        const unsigned long t_LB = (lastBW_Len > minDeadline) ? lastBW_Len : minDeadline;

        //if(!rawPDC(t_LB, newBW_Len))
        if(!QPA(t_LB, newBW_Len))
            return false;
        
		lastBW_Len = newBW_Len;
	}

	return true;
}

// Compute the last check-point < interval_length for the PDC 
unsigned long PEDFBlockingAnalysis::lastCheckPointBefore(unsigned long interval_length)
{
    unsigned long lastCheckPoint = 0;
    
    foreach(info.get_tasks(), T_i)
    {
        // Local tasks 
        if(T_i->get_cluster()==cluster && T_i->get_deadline()<interval_length)
        {
            // steps of nljobs(T_i,t)
            unsigned long d = divide_with_floor(interval_length - T_i->get_deadline(),T_i->get_period())*
                              T_i->get_period() + T_i->get_deadline();
            if(d==interval_length) d = d - T_i->get_period();
            if(d>lastCheckPoint) lastCheckPoint = d;
            
            // steps of ceil(T_i,t)
            const unsigned int njobs = divide_with_ceil(interval_length,T_i->get_period());
            d = (njobs-1)*T_i->get_period() +1;
            if(d==interval_length) d = d - T_i->get_period();
            if(d>lastCheckPoint) lastCheckPoint = d;
        }
        
        // Remote tasks
        if(T_i->get_cluster() != cluster)
        {
            // steps of nrjobs(T_i,t)
            const unsigned int njobs = divide_with_ceil(interval_length + T_i->get_deadline(),T_i->get_period());
            if(njobs>1)
            {
                unsigned long d = (njobs-1)*T_i->get_period() - T_i->get_deadline() +1;
                if(d==interval_length) d = d - T_i->get_period();
                if(d>lastCheckPoint) lastCheckPoint = d;
            }
        }
    }
    
    return lastCheckPoint;
}

// [QPA] --- Smart implementation of the PDC
// Zhang and Burns - "Schedulability Analysis for Real-Time Systems with EDF Scheduling"
// IEEE Transaction of Computers, 2009
bool PEDFBlockingAnalysis::QPA(unsigned long t_LB, unsigned long t_UB)
{
    unsigned long checkPoint = lastCheckPointBefore(t_UB);
    unsigned long totalDemand = 0;
    while(true)
    {
        if(checkPoint < t_LB) break;
        
        #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
        std::cout << "[QPA] Checking t = " << checkPoint << std::endl;
        #endif
        
        // First compute a coarse-grain upper-bound with integer relaxation
        unsigned long blk = computeBlockingPDC(checkPoint);
        totalDemand = DBF(checkPoint) + blk;
        
        #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
        std::cout << "[QPA] Blk UB = " << blk << " totalDemand = " << totalDemand << std::endl;
        #endif
        
        if(totalDemand <= t_LB) break;
        if(totalDemand > checkPoint)
        {
            // Compute the actual upper-bound without integer relaxation
            blk = computeTighterBlockingPDC(checkPoint, blk);
            totalDemand = DBF(checkPoint) + blk;
            
            #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
            std::cout << "[QPA] Blk Tight = " << blk << " totalDemand = " << totalDemand << std::endl;
            #endif
            
            if(totalDemand > checkPoint) 
            {
                 #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
                 std::cout << "[QPA] Deadline miss at t = " << checkPoint << std::endl;
                 #endif
                return false;
            }
        }
        
        // Move to the next check-point
        if(totalDemand <  checkPoint) 
            checkPoint = totalDemand;
        else // totalDemand == checkPoint
            checkPoint = lastCheckPointBefore(checkPoint);
    }

    return true;
}

// Dumb implementation of the PDC
bool PEDFBlockingAnalysis::rawPDC(unsigned long t_LB, unsigned long t_UB)
{
    //foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
    foreach(info.get_tasks(), T_i)
    {
        unsigned long checkPoint;
        unsigned int nJobs = -1;
        unsigned long totalDemand = 0;
        
        while(true)
        {
            nJobs++;
            // Local tasks
            if(T_i->get_cluster() == cluster)
                checkPoint = T_i->get_deadline() + nJobs*T_i->get_period();    
            // Remote tasks
            else 
                checkPoint = (nJobs+1)*T_i->get_period() - T_i->get_deadline() + 1;    
            
            if(checkPoint < t_LB) continue;
            if(checkPoint > t_UB) break;
                
             if(checkPoint < t_LB) break;
        
            #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
            std::cout << "Checking t = " << checkPoint << std::endl;
            #endif
            
            // First compute a coarse-grain upper-bound with integer relaxation
            unsigned long blk = computeBlockingPDC(checkPoint);
            totalDemand = DBF(checkPoint) + blk;
            
            #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
            std::cout << "Blk UB = " << blk << " totalDemand = " << totalDemand << std::endl;
            #endif
            
            if(totalDemand > checkPoint)
            {
                // Compute the actual upper-bound without integer relaxation
                blk = computeTighterBlockingPDC(checkPoint, blk);
                totalDemand = DBF(checkPoint) + blk;
                
                #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
                std::cout << "Blk Tight = " << blk << " totalDemand = " << totalDemand << std::endl;
                #endif
                
                if(totalDemand > checkPoint) 
                {                
                     #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
                     std::cout << "Deadline miss at t = " << checkPoint << std::endl;
                     #endif
                    return false;
                }
            }
        }
    }
    return true;
}


