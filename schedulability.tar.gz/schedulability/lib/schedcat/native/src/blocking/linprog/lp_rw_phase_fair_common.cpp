#include <stdint.h>
#include <cassert>
#include <climits>
#include <cmath>

#include "linprog/varmapperbase.h"
#include "linprog/solver.h"

#include "sharedres_types.h"

#include "iter-helper.h"
#include "stl-helper.h"
#include "stl-io-helper.h"
#include "math-helper.h"

#include <iostream>
#include <sstream>
#include "res_io.h"
#include "linprog/io.h"

#include "lp_rw_phase_fair_common.h"

//#define __DEBUG_PEDF_SPINLOCKS__

std::string SpinVarMapperRW::key2str(uint64_t key, unsigned int var) const
{
	lookup_key_t k;
	std::ostringstream buf;

	k.raw = key;

	switch (k.var.variable_type)
	{
		case SPIN_BLOCKING_READ:
			buf << "Xsr";
			break;
		case SPIN_BLOCKING_WRITE:
			buf << "Xsw";
			break;
		case ARRIVAL_BLOCKING_READ:
			buf << "Xar";
			break;
		case ARRIVAL_BLOCKING_WRITE:
			buf << "Xaw";
			break;
        	case INDICATOR_ARRIVAL_BLOCKING_READ:
			buf << "Ar";
			break; 
		case INDICATOR_ARRIVAL_BLOCKING_WRITE:
			buf << "Aw";
			break;
        	case CANCELLATIONS:
			buf << "C";
			break; 
		case SPIN_BLOCKING_READ_TO_READ:
			buf << "Xsrr";
			break;
		case SPIN_BLOCKING_READ_TO_WRITE:
			buf << "Xsrw";
			break;
		case SPIN_BLOCKING_WRITE_TO_READ:
			buf << "Xswr";
			break;
		case SPIN_BLOCKING_WRITE_TO_WRITE:
			buf << "Xsww";
			break;
		case Y:
			buf << "Y";
			break;
	}

	buf << "["
		<< k.var.tid << ", "
		<< k.var.rid << "]";

	return buf.str();
}


// ------------------------------------------------------------------
// -----------------------------[ L P ]------------------------------
// ------------------------------------------------------------------


PEDFBlockingAnalysisLP_Spinlocks_RW::PEDFBlockingAnalysisLP_Spinlocks_RW(
	const ResourceSharingInfo& _info,
	analysis_type_t atype,
	unsigned long delta,
    	unsigned int _cluster)
	: taskset(_info.get_tasks()),
      info(_info),
	  lp_type(atype),
	  interval_length(delta),
      cluster(_cluster),
	  all_resources(get_all_resources(_info))
{
    // Add generic constraints
    read_add_no_arrival_blocking_dline_inside_interval();
    write_add_no_arrival_blocking_dline_inside_interval();
    read_add_no_spin_delay_local_requests();
    write_add_no_spin_delay_local_requests();
    read_add_joint_upper_bound_remote_requests();
    write_add_joint_upper_bound_remote_requests();
    add_upper_bound_on_read_arrival_blocking_by_number_of_requests();
    add_upper_bound_on_write_arrival_blocking_by_number_of_requests();
    add_upper_bound_on_read_arrival_blocking();
    add_upper_bound_on_write_arrival_blocking();

    if(atype==AC_MODE)
        add_no_arrival_blocking();
    if(atype==PDC_MODE)
        add_upper_bound_on_arrival_blocking();

    set_objective();
}
unsigned long PEDFBlockingAnalysisLP_Spinlocks_RW::solve(bool verbose)
{
	Solution *sol;
	double result;

//	add_constraints_post_ctor();

	if (verbose)
	{
		hashmap<unsigned int, std::string> var_map;

		var_map = vars.get_translation_table();

		std::cout << std::endl
			<< "=====================================================" << std::endl;
		std::cout << "LP for t=" << interval_length << ":" << std::endl;
		pretty_print_linear_program(std::cout, *this, var_map) << std::endl;

		sol = linprog_solve(*this, vars.get_num_vars());
		result = ceil(sol->evaluate(*get_objective()));

		std::cout << "Solution: " << result << std::endl;
		for (unsigned int x = 0; x < vars.get_num_vars(); x++)
		{
			std::cout << "X" << x
				<< ": " << var_map[x]
				<< " = " << sol->get_value(x)
				<< std::endl;
		}
	}
	else
	{
		sol = linprog_solve(*this, vars.get_num_vars());
		result = ceil(sol->evaluate(*get_objective()));
	}

	delete sol;
	assert(result < ULONG_MAX);
	return (unsigned long) result;
}

// ------------------------------------------------------------------
// ----------------------[ O B J E C T I V E ]-----------------------
// ------------------------------------------------------------------
void  PEDFBlockingAnalysisLP_Spinlocks_RW::set_objective()
{
        LinearExpression *obj = get_objective();

        foreach(taskset, T_x)
        {
                const unsigned int x = T_x->get_id();
                foreach(all_resources, q_iter)
                {
                        const unsigned int q = *q_iter;
                        
			const double length_read = T_x->get_read_request_length(q);
			const double length_write = T_x->get_write_request_length(q);

                        var_t X_SPIN_READ    = vars.spin_read(x, q);
                        var_t X_SPIN_WRITE   = vars.spin_write(x, q);
                        var_t X_ARRIVAL_READ = vars.arrival_read(x, q);
                        var_t X_ARRIVAL_WRITE = vars.arrival_write(x,q);


                        declare_variable_bounds(X_SPIN_READ,     true, 0, false, 0);
                        declare_variable_bounds(X_SPIN_WRITE,     true, 0, false, 0);
                        declare_variable_bounds(X_ARRIVAL_READ,  true, 0, false, 0);
                        declare_variable_bounds(X_ARRIVAL_WRITE,  true, 0, false, 0);

                        declare_variable_integer(X_SPIN_READ);
                        declare_variable_integer(X_SPIN_WRITE);
                        declare_variable_integer(X_ARRIVAL_READ);
                        declare_variable_integer(X_ARRIVAL_WRITE);

                        obj->add_term(length_read, X_SPIN_READ);
                        obj->add_term(length_write, X_SPIN_WRITE);
                        obj->add_term(length_read, X_ARRIVAL_READ);
                        obj->add_term(length_write, X_ARRIVAL_WRITE);

                        var_t X_SPIN_READ_TO_READ = vars.spin_read_to_read(x, q);
                        var_t X_SPIN_READ_TO_WRITE = vars.spin_read_to_write(x, q);
                        var_t X_SPIN_WRITE_TO_READ = vars.spin_write_to_read(x, q);
                        var_t X_SPIN_WRITE_TO_WRITE = vars.spin_write_to_write(x, q);
			
                        declare_variable_bounds(X_SPIN_READ_TO_READ,     true, 0, false, 0);
                        declare_variable_bounds(X_SPIN_READ_TO_WRITE,     true, 0, false, 0);
                        declare_variable_bounds(X_SPIN_WRITE_TO_READ,     true, 0, false, 0);
                        declare_variable_bounds(X_SPIN_WRITE_TO_WRITE,     true, 0, false, 0);

                        declare_variable_integer(X_SPIN_READ_TO_READ);
                        declare_variable_integer(X_SPIN_READ_TO_WRITE);
                        declare_variable_integer(X_SPIN_WRITE_TO_READ);
                        declare_variable_integer(X_SPIN_WRITE_TO_WRITE);
		}
        }
}


// ------------------------------------------------------------------
// --------------------[ C O N S T R A I N T S ]---------------------
// ------------------------------------------------------------------

// Constraint: No arrival blocking from tasks with d_i <= t
void PEDFBlockingAnalysisLP_Spinlocks_RW::read_add_no_arrival_blocking_dline_inside_interval()
{
    foreach_task_in_cluster_having_leq_dline(taskset, cluster, interval_length, T_i)
    {
        const unsigned int i = T_i->get_id();
        
        foreach(T_i->get_requests(), request)
        {
	    if(request->is_read()){
            	const unsigned int q = request->get_resource_id();
            
            	var_t X_ARRIVAL_READ = vars.arrival_read(i, q);
            	LinearExpression *exp = new LinearExpression();
            	exp->add_var(X_ARRIVAL_READ);
            	// X_ARRIVAL_READ <= 0
            	add_inequality(exp, 0);
	    }
        }
    }    
}
void PEDFBlockingAnalysisLP_Spinlocks_RW::write_add_no_arrival_blocking_dline_inside_interval()
{
    foreach_task_in_cluster_having_leq_dline(taskset, cluster, interval_length, T_i)
    {
        const unsigned int i = T_i->get_id();

        foreach(T_i->get_requests(), request)
        {
            if(request->is_write()){
                const unsigned int q = request->get_resource_id();

                var_t X_ARRIVAL_WRITE = vars.arrival_write(i, q);
                LinearExpression *exp = new LinearExpression();
                exp->add_var(X_ARRIVAL_WRITE);
                // X_ARRIVAL_WRITE <= 0
                add_inequality(exp, 0);
            }
        }
    }
}

// Constraint: No spin delay from local requests
void PEDFBlockingAnalysisLP_Spinlocks_RW::read_add_no_spin_delay_local_requests()
{
    LinearExpression *exp = new LinearExpression();
    
    foreach_task_in_cluster(taskset, cluster, T_i)
    {
        const unsigned int i = T_i->get_id();
        
        foreach(T_i->get_requests(), request)
        {
	    if(request->is_read()){
            	const unsigned int q = request->get_resource_id();
            
            	var_t X_SPIN_READ = vars.spin_read(i, q);
            	exp->add_var(X_SPIN_READ);
	    }
        }
    }    
    
    add_inequality(exp, 0);
}
void PEDFBlockingAnalysisLP_Spinlocks_RW::write_add_no_spin_delay_local_requests()
{
    LinearExpression *exp = new LinearExpression();

    foreach_task_in_cluster(taskset, cluster, T_i)
    {
        const unsigned int i = T_i->get_id();

        foreach(T_i->get_requests(), request)
        {
            if(request->is_write()){
                const unsigned int q = request->get_resource_id();

                var_t X_SPIN_WRITE = vars.spin_write(i, q);
                exp->add_var(X_SPIN_WRITE);
            }
        }
    }

    add_inequality(exp, 0);
}

// Constraint:  upper-bound for remote requests
void PEDFBlockingAnalysisLP_Spinlocks_RW::read_add_joint_upper_bound_remote_requests()
{
    foreach_task_not_in_cluster(taskset, cluster, T_i)
    {
        const unsigned int i = T_i->get_id();
        unsigned int nrjobs = T_i->get_pedf_max_num_remote_jobs(interval_length);

        foreach(all_resources,q_iter)
        {
            const unsigned int q = *q_iter;
            unsigned int N_i_q_read = T_i->get_num_read_requests(q);

            var_t X_ARRIVAL_READ = vars.arrival_read(i, q);
            var_t X_SPIN_READ    = vars.spin_read(i, q);

            LinearExpression *exp = new LinearExpression();
            exp->add_var(X_ARRIVAL_READ);
            exp->add_var(X_SPIN_READ);

            add_inequality(exp, nrjobs*N_i_q_read);
        }
    }
}

void PEDFBlockingAnalysisLP_Spinlocks_RW::write_add_joint_upper_bound_remote_requests()
{
    foreach_task_not_in_cluster(taskset, cluster, T_i)
    {
        const unsigned int i = T_i->get_id();
        unsigned int nrjobs = T_i->get_pedf_max_num_remote_jobs(interval_length);

        foreach(all_resources,q_iter)
        {
            const unsigned int q = *q_iter;
            unsigned int N_i_q_write = T_i->get_num_write_requests(q);

            var_t X_ARRIVAL_WRITE = vars.arrival_write(i, q);
            var_t X_SPIN_WRITE = vars.spin_write(i, q);

            LinearExpression *exp = new LinearExpression();
            exp->add_var(X_ARRIVAL_WRITE);
            exp->add_var(X_SPIN_WRITE);

            add_inequality(exp, nrjobs*N_i_q_write);
        }
    }
}

void PEDFBlockingAnalysisLP_Spinlocks_RW::add_upper_bound_on_arrival_blocking()
{
    LinearExpression *exp = new LinearExpression();
    foreach(all_resources,q_iter)
    {
        const unsigned int q = *q_iter;

        var_t X_INDICATOR_ARRIVAL_BLOCKING_READ = vars.indicator_arrival_read(q);
        var_t X_INDICATOR_ARRIVAL_BLOCKING_WRITE = vars.indicator_arrival_write(q);
	
	declare_variable_binary(X_INDICATOR_ARRIVAL_BLOCKING_READ);
	declare_variable_binary(X_INDICATOR_ARRIVAL_BLOCKING_WRITE);

        exp->add_var(X_INDICATOR_ARRIVAL_BLOCKING_READ);
	exp->add_var(X_INDICATOR_ARRIVAL_BLOCKING_WRITE);
    }

    add_inequality(exp, 1);
}

void PEDFBlockingAnalysisLP_Spinlocks_RW::add_no_arrival_blocking()
{
    LinearExpression *exp = new LinearExpression();
    foreach(all_resources,q_iter)
    {
        const unsigned int q = *q_iter;

        var_t X_INDICATOR_ARRIVAL_BLOCKING_READ = vars.indicator_arrival_read(q);
        var_t X_INDICATOR_ARRIVAL_BLOCKING_WRITE = vars.indicator_arrival_write(q);
	
	declare_variable_binary(X_INDICATOR_ARRIVAL_BLOCKING_READ);
	declare_variable_binary(X_INDICATOR_ARRIVAL_BLOCKING_WRITE);

        exp->add_var(X_INDICATOR_ARRIVAL_BLOCKING_READ);
	exp->add_var(X_INDICATOR_ARRIVAL_BLOCKING_WRITE);
    }

    add_inequality(exp, 0);
}

void PEDFBlockingAnalysisLP_Spinlocks_RW::add_upper_bound_on_read_arrival_blocking_by_number_of_requests()
{
    foreach(all_resources,q_iter)
    {
        const unsigned int q = *q_iter;
        unsigned int n_reqs_read = 0;

        foreach_task_in_cluster_having_gr_dline(info.get_tasks(), cluster, interval_length, T_i)
            n_reqs_read += T_i->get_num_read_requests(q);

        var_t A_q = vars.indicator_arrival_read(q);
        declare_variable_binary(A_q);

        LinearExpression *exp = new LinearExpression();
        exp->add_var(A_q);
        // A_q <= n_reqs
        add_inequality(exp,n_reqs_read);
    }	
}

void PEDFBlockingAnalysisLP_Spinlocks_RW::add_upper_bound_on_write_arrival_blocking_by_number_of_requests()
{
    foreach(all_resources,q_iter)
    {
        const unsigned int q = *q_iter;
        unsigned int n_reqs_write = 0;

        foreach_task_in_cluster_having_gr_dline(info.get_tasks(), cluster, interval_length, T_i)
            n_reqs_write += T_i->get_num_write_requests(q);

        var_t A_q = vars.indicator_arrival_write(q);
        declare_variable_binary(A_q);

        LinearExpression *exp = new LinearExpression();
        exp->add_var(A_q);
        // A_q <= n_reqs
        add_inequality(exp,n_reqs_write);
    }


}

void PEDFBlockingAnalysisLP_Spinlocks_RW::add_upper_bound_on_read_arrival_blocking()
{
    foreach(all_resources,q_iter)
    {
	LinearExpression *exp = new LinearExpression();
        const unsigned int q = *q_iter;

	//calculate arrival blocking whenever a task accesses reqsource q
	foreach_task_in_cluster(taskset, cluster, T_i)
    	{
       		const unsigned int i = T_i->get_id();

               	var_t X_ARRIVAL_READ = vars.arrival_read(i, q);
               	exp->add_var(X_ARRIVAL_READ);
    	}

        var_t X_INDICATOR_ARRIVAL_READ = vars.indicator_arrival_read(q);
        declare_variable_binary(X_INDICATOR_ARRIVAL_READ);
	exp->sub_var(X_INDICATOR_ARRIVAL_READ);

        add_inequality(exp,0);
    }

}

void PEDFBlockingAnalysisLP_Spinlocks_RW::add_upper_bound_on_write_arrival_blocking()
{
     foreach(all_resources,q_iter)
    {
        LinearExpression *exp = new LinearExpression();
        const unsigned int q = *q_iter;

        //calculate arrival blocking whenever a task accesses reqsource q
        foreach_task_in_cluster(taskset, cluster, T_i)
        {
                const unsigned int i = T_i->get_id();

                var_t X_ARRIVAL_WRITE = vars.arrival_write(i, q);
                exp->add_var(X_ARRIVAL_WRITE);
        }

        var_t X_INDICATOR_ARRIVAL_WRITE = vars.indicator_arrival_write(q);
        declare_variable_binary(X_INDICATOR_ARRIVAL_WRITE);
	exp->sub_var(X_INDICATOR_ARRIVAL_WRITE);

        add_inequality(exp,0);
    }
}
