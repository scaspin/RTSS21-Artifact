#include <stdint.h>
#include <cassert>
#include <climits>
#include <cmath>
#include <iostream>
#include <sstream>
#include <map>
#include <vector>

#include "sharedres.h"
#include "sharedres_types.h"
#include "blocking.h"
#include "tasks.h"

#include "lp_pedf_analysis.h"
#include "iter-helper.h"
#include "stl-helper.h"
#include "stl-io-helper.h"
#include "math-helper.h"

unsigned long L_max = 30; /*set to minimum possible length*/
ResourceSharingInfo& info = *(new ResourceSharingInfo(1));
unsigned long cluster;

unsigned long gcd1(unsigned long a, unsigned long b)
{
    while(true)
    {
        if (a == 0) return b;
        b %= a;
        if (b == 0) return a;
        a %= b;
    }
}

unsigned long lcm1(unsigned long a, unsigned long b)
{
    unsigned long temp = gcd1(a, b);
    return temp ? (a / temp * b) : 0;
}

unsigned long arrival_curve(unsigned long interval_length)
{
    unsigned long retval = 0;
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        retval += T_i->get_pedf_AC_max_num_local_jobs(interval_length)*T_i->get_cost();
    return retval;
}

unsigned long DBF(unsigned long interval_length)
{
    unsigned long retval = 0;
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        retval += T_i->get_pedf_PDC_max_num_local_jobs(interval_length)*T_i->get_cost();
    return retval;
}

bool share_resources(const std::vector<RequestBound> r_list1, const std::vector<RequestBound> r_list2)
{
   unsigned int i, j;
   for(i = 0; i < r_list1.size(); i++)
   {
       for(j = 0; j < r_list2.size(); j++)
       {
           if(r_list1[i].get_resource_id() == r_list2[j].get_resource_id() && r_list2[j].is_write())
           {
               return true;
           }
       }
   }
   return false;
}
bool share_resources_with_request(const std::vector<RequestBound> r_list, unsigned int id, bool  is_write)
{
   if(!is_write)
   {
       return false;
   }
   unsigned int i;
   for(i = 0; i < r_list.size(); i++)
   {
	   if(r_list[i].get_resource_id() == id)
           {
               return true;
           }
   }
   return false;
}


/*helper functions for pdc and ac calculations)*/
/*
unsigned long nljobs_pdc(Task& T, int t){
    return std::floor((t+T->get_period() - T->get_deadline())/ T->get_period());
}
unsigned long nljobs_ac(Task& T, int t){
    return std::ceil(t/T->get_period());
}
unsigned long nrjobs(Task& T, int t){
    return std::ceil((t+T->get_deadline())/T->get_period());	
}

bool share_resources(Task &T_i, Task &T_j){
    foreach(T_i->get_requests(), request_i){
        foreach(T_j->get_requests(), request_j){
             if(request_i->get_resource_id() == request->get_resource_id())
                 return true;
        }
    } 
}

unsigned long num_shared_resource(Task &T_i, Task &T_j){
    unsigned long num = 0;
    foreach(T_i->get_requests(), request_i){
        foreach(T_j->get_requests(), request_j){
             if(request_i->get_resource_id() == request->get_resource_id())
                 num++;
	}
    }
    return num;   
}*/

/*the two bounds to edit*/
unsigned long computeBlockingPDC(unsigned long interval_length)
{
    unsigned int B_PDC = 0;
    foreach_task_in_cluster(info.get_tasks(),cluster, T_i){
	    foreach(info.get_tasks(), T_j){
		if(T_i != T_j){
		    if(T_j->get_cluster()==cluster && T_j->get_period()<T_i->get_period()){
			//calculate if any resources are shared
			if(share_resources(T_i->get_requests(), T_j->get_requests())){
				 B_PDC += std::floor((interval_length+T_j->get_period()-T_j->get_deadline())/T_j->get_period())*L_max;
			}
		    }else if(T_j->get_cluster()!=cluster){
			unsigned long num = 0;
			foreach(T_j->get_requests(), request_j){
    				if(share_resources_with_request(T_i->get_requests(), request_j->get_resource_id(), request_j->is_write())){
        				num++;
    				}
			}	
			B_PDC += std::ceil((float)(interval_length+T_j->get_deadline())/(float)T_j->get_period()) * num * L_max;
		    }
		}		
	    }
    }
    //std::cout << B_PDC;
    return B_PDC;
}

unsigned long computeBlockingAC( unsigned long interval_length)
{
    unsigned int B_AC = 0;
    foreach_task_in_cluster(info.get_tasks(), cluster, T_i){
    	foreach(info.get_tasks(), T_j){
                if(T_i != T_j){
                    if(T_j->get_cluster()==cluster && T_j->get_period()<T_i->get_period()){
                        //calculate if any resources are shared
                        if (share_resources(T_i->get_requests(), T_j->get_requests())){
			    B_AC += std::ceil(interval_length/T_j->get_period())*L_max;
			}
		    }else if(T_j->get_cluster()!=cluster){
                        unsigned long num = 0;
                        foreach(T_j->get_requests(), request_j){
                                if(share_resources_with_request(T_i->get_requests(), request_j->get_resource_id(), request_j->is_write())){
                                        num++;
                                }       
                        }
                        B_AC += std::ceil((float)(interval_length+T_j->get_deadline())/(float)T_j->get_period()) * num * L_max;
                    }
                }
            }
    }
    return B_AC;
}

unsigned long lastCheckPointBefore(unsigned long interval_length)
{
    unsigned long lastCheckPoint = 0;
    
    foreach(info.get_tasks(), T_i)
    {
        // Local tasks 
        if(T_i->get_cluster()==cluster && T_i->get_deadline()<interval_length)
        {
            // steps of nljobs(T_i,t)
            unsigned long d = divide_with_floor(interval_length - T_i->get_deadline(),T_i->get_period())*
                              T_i->get_period() + T_i->get_deadline();
            if(d==interval_length) d = d - T_i->get_period();
            if(d>lastCheckPoint) lastCheckPoint = d;
            
            // steps of ceil(T_i,t)
            const unsigned int njobs = divide_with_ceil(interval_length,T_i->get_period());
            d = (njobs-1)*T_i->get_period() +1;
            if(d==interval_length) d = d - T_i->get_period();
            if(d>lastCheckPoint) lastCheckPoint = d;
        }
        
        // Remote tasks
        if(T_i->get_cluster() != cluster)
        {
            // steps of nrjobs(T_i,t)
            const unsigned int njobs = divide_with_ceil(interval_length + T_i->get_deadline(),T_i->get_period());
            if(njobs>1)
            {
                unsigned long d = (njobs-1)*T_i->get_period() - T_i->get_deadline() +1;
                if(d==interval_length) d = d - T_i->get_period();
                if(d>lastCheckPoint) lastCheckPoint = d;
            }
        }
    }
    
    return lastCheckPoint;
}

//from lp_pedf_analysis QPA
bool QPA(unsigned long t_LB, unsigned long t_UB)
{
    unsigned long checkPoint = lastCheckPointBefore(t_UB);
    unsigned long totalDemand = 0;
    while(true)
    {
        if(checkPoint < t_LB) break;
        
        #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
        std::cout << "[QPA] Checking t = " << checkPoint << std::endl;
        #endif
        
        // First compute a coarse-grain upper-bound with integer relaxation
        unsigned long blk = computeBlockingPDC(checkPoint);
        totalDemand = DBF(checkPoint) + blk;
        
        #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
        std::cout << "[QPA] Blk UB = " << blk << " totalDemand = " << totalDemand << std::endl;
        #endif
        
        if(totalDemand <= t_LB) break;
 /*       if(totalDemand > checkPoint)
        {
            // Compute the actual upper-bound without integer relaxation
            blk = computeTighterBlockingPDC(checkPoint, blk);
            totalDemand = DBF(checkPoint) + blk;
            
            #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
            std::cout << "[QPA] Blk Tight = " << blk << " totalDemand = " << totalDemand << std::endl;
            #endif
         */   
            if(totalDemand > checkPoint) 
            {
                /* #ifdef __DEBUG_PEDF_BLK_ANALYSIS__
                 std::cout << "[QPA] Deadline miss at t = " << checkPoint << std::endl;
                 #endif*/
                return false;
            }
                
        // Move to the next check-point
        if(totalDemand <  checkPoint) 
            checkPoint = totalDemand;
        else // totalDemand == checkPoint
            checkPoint = lastCheckPointBefore(checkPoint);
    }

    return true;
}


bool tl2_is_schedulable(const ResourceSharingInfo& rinfo)
{
   info = rinfo;
  
   /*calculate max critical section length for L_max*/ 
   unsigned long max_csl = 0;   
   foreach(info.get_tasks(), task){
	   foreach(task->get_requests(), req){
		if(req->get_request_length() > max_csl)
			max_csl = req->get_request_length();
   
	   }
   }
   L_max = max_csl;

   foreach_cluster(info, k){
    	unsigned long lastBW_Len = 1;
    	unsigned long hyper_period = 1;
 
    	cluster = k;

	/* from declaration of blocking bounds in lp_pedf_analysis*/
    	unsigned int maxDeadline = 0;

    	foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        	maxDeadline = (maxDeadline > T_i->get_deadline() ? maxDeadline : T_i->get_deadline());

    	unsigned int minDeadline = maxDeadline;

    	foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
        	minDeadline = (T_i->get_deadline() < minDeadline ? T_i->get_deadline() : minDeadline);

    	foreach_task_in_cluster(info.get_tasks(), cluster, T_i)
    	{	
        	hyper_period = lcm1(hyper_period,T_i->get_period());
    	}
    
    	#ifdef __DEBUG_PEDF_BLK_ANALYSIS__
    	std::cout << "#Hyper-period = " << hyper_period << std::endl;
    	#endif
    
    	// Perform PDC until the first idle-time
	while(true)
	{	
		// Fixed-point iteration step
        	unsigned long newBW_Len = arrival_curve(lastBW_Len) + computeBlockingAC(lastBW_Len);
        
        	#ifdef __DEBUG_PEDF_BLK_ANALYSIS__
		std::cout << "#ARRCRV Update : lastBW_Len = " << lastBW_Len << ", newBW_Len=" << newBW_Len << std::endl;
       		#endif
        
		if(newBW_Len == lastBW_Len)     break;
        
        	const unsigned long t_LB = (lastBW_Len > minDeadline) ? lastBW_Len : minDeadline;

        	if(!QPA(t_LB, newBW_Len))
            	return false;
        
			lastBW_Len = newBW_Len;
		}	

    }
    return true;
}
