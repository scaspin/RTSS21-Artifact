"""
schedcat.util: misc. helpers
"""
