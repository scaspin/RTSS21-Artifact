from __future__ import division

import unittest
import random

import schedcat.locking.bounds as lb
import schedcat.locking.native as cpp
import schedcat.model.tasks as tasks
import schedcat.model.resources as r

import schedcat.util.linprog

class PEDF_Spinlocks(unittest.TestCase):
    def setUp(self):
        self.trivial_ts = tasks.TaskSystem([
                tasks.SporadicTask(1018, 181000, 181000),
                tasks.SporadicTask(47421, 373000, 373000),
                tasks.SporadicTask(140, 1000, 1000),
                tasks.SporadicTask(37734, 137000, 137000),
                tasks.SporadicTask(372, 1000, 1000),
                tasks.SporadicTask(51536, 181000, 181000),
                tasks.SporadicTask(3041, 15000, 15000),
                tasks.SporadicTask(204, 2000, 2000),
                tasks.SporadicTask(2050, 8000, 8000),
                tasks.SporadicTask(20716, 339000, 339000),
            ])
        self.trivial_num_cpus = 2
       
        
        r.initialize_resource_model(self.trivial_ts)
        lb.assign_edf_preemption_levels(self.trivial_ts)

        #for i, t in enumerate(self.trivial_ts):
        #    t.partition = 0
        #    t.response_time = 4*t.cost
        
        self.trivial_ts[0].partition = 0;
        self.trivial_ts[2].partition = 0;
        self.trivial_ts[4].partition = 0;
        self.trivial_ts[6].partition = 0;
        self.trivial_ts[8].partition = 0;
        self.trivial_ts[1].partition = 1;
        self.trivial_ts[3].partition = 1;
        self.trivial_ts[5].partition = 1;
        self.trivial_ts[7].partition = 1;
        self.trivial_ts[9].partition = 1;
        
        # ---------------------------------------------------
        # ----------------[ Reuqests ]-----------------------
        # ---------------------------------------------------
        self.trivial_ts[0].resmodel[0].add_request(12)
        self.trivial_ts[0].resmodel[0].add_request(12)
        self.trivial_ts[0].resmodel[0].add_request(12)
        self.trivial_ts[0].resmodel[1].add_request(3)
        self.trivial_ts[0].resmodel[1].add_request(3)
        self.trivial_ts[0].resmodel[1].add_request(3)
        self.trivial_ts[0].resmodel[1].add_request(3)
        self.trivial_ts[0].resmodel[1].add_request(3)
        self.trivial_ts[2].resmodel[0].add_request(14)
        self.trivial_ts[2].resmodel[0].add_request(14)
        self.trivial_ts[2].resmodel[0].add_request(14)
        self.trivial_ts[2].resmodel[0].add_request(14)
        self.trivial_ts[2].resmodel[0].add_request(14)
        self.trivial_ts[2].resmodel[3].add_request(10)
        self.trivial_ts[2].resmodel[3].add_request(10)
        self.trivial_ts[2].resmodel[3].add_request(10)
        self.trivial_ts[2].resmodel[3].add_request(10)
        self.trivial_ts[2].resmodel[3].add_request(10)
        self.trivial_ts[2].resmodel[3].add_request(10)
        self.trivial_ts[2].resmodel[3].add_request(10)
        self.trivial_ts[4].resmodel[0].add_request(24)
        self.trivial_ts[4].resmodel[0].add_request(24)
        self.trivial_ts[4].resmodel[0].add_request(24)
        self.trivial_ts[4].resmodel[0].add_request(24)
        self.trivial_ts[4].resmodel[0].add_request(24)
        self.trivial_ts[4].resmodel[0].add_request(24)
        self.trivial_ts[4].resmodel[0].add_request(24)
        self.trivial_ts[5].resmodel[1].add_request(19)
        self.trivial_ts[5].resmodel[1].add_request(19)
        self.trivial_ts[5].resmodel[1].add_request(19)
        self.trivial_ts[5].resmodel[1].add_request(19)
        self.trivial_ts[5].resmodel[1].add_request(19)
        self.trivial_ts[5].resmodel[1].add_request(19)
        self.trivial_ts[5].resmodel[1].add_request(19)
        self.trivial_ts[7].resmodel[1].add_request(20)
        self.trivial_ts[9].resmodel[1].add_request(24)
        self.trivial_ts[9].resmodel[1].add_request(24)
        self.trivial_ts[9].resmodel[1].add_request(24)
        self.trivial_ts[9].resmodel[1].add_request(24)
        # ---------------------------------------------------
        # ---------------------------------------------------
    '''
    @unittest.skipIf(not schedcat.locking.bounds.lp_cpp_available, "no native LP solver available")
    def test_MSRP(self):
        if lb.pedf_msrp_is_schedulable(self.trivial_ts):
            print "[MSRP] SCHEDULABLE";
        else:
            print "[MSRP] NOT SCHEDULABLE";
    
    @unittest.skipIf(not schedcat.locking.bounds.lp_cpp_available, "no native LP solver available")
    def test_FIFO_preempt(self):
        if lb.pedf_fifo_preempt_is_schedulable(self.trivial_ts):
            print "[FIFO Preemptive] SCHEDULABLE";
        else:
            print "[FIFO Preemptive] NOT SCHEDULABLE";
    
    def test_MSRP_classic(self):
        if lb.pedf_msrp_classic_is_schedulable(self.trivial_ts, self.trivial_num_cpus):
            print "[MSRP Classic] SCHEDULABLE";
        else:
            print "[MSRP Classic] NOT SCHEDULABLE";
    '''
    @unittest.skipIf(not schedcat.locking.bounds.lp_cpp_available, "no native LP solver available")
    def test_lockfree_preempt(self):
        if lb.pedf_lockfree_preempt_is_schedulable(self.trivial_ts):
            print "[Lock-Free Preemptive] SCHEDULABLE";
        else:
            print "[Lock-Free Preemptive] NOT SCHEDULABLE";
            
    '''       
    @unittest.skipIf(not schedcat.locking.bounds.lp_cpp_available, "no native LP solver available")
    def test_lockfree_NP(self):
        if lb.pedf_lockfree_NP_is_schedulable(self.trivial_ts):
            print "[Lock-Free NP] SCHEDULABLE";
        else:
            print "[Lock-Free NP] NOT SCHEDULABLE";
        #self.assertEqual(self.trivial_ts[0].response_time, self.trivial_ts[0].cost + 75)
    '''    