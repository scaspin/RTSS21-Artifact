#!/usr/bin/env python
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import csv
import string
import math
from csv import DictReader
from copy import copy
from collections import defaultdict

LINE_STYLE = ["s-", "^-", "o--", ".:", ".:"]
LINE_COLOR = ["k", "#d95f02", "#1b9e77", "#7570b3", "#7570b3"]

chosen_lines = ['NOLOCK', 'PFTL-LP', 'NEW-LP']
chosen_lines = ['no-blocking','Phase-Fair-RW',"pftl-blocking"]
#chosen_lines = ['NOLOCK','PF-T-Overhead','PF-L-Overhead']
chosen_lines = ['NOLOCK','Phase-Fair-RW',"lockfree_NP","lockfree_NP_no_reads"]

WIDTH=5
HEIGHT=3

def chooseLabel(colName):
    if colName == "no-blocking":
        return "NOLOCK"
    elif colName == "PFTL-LP":
        return "LP+PF-T"
    elif colName == "NEW-LP":
        return "LP+PF-L"
    elif colName == "TL2":
        return "TL2"
    elif colName == "TL2-collapse":
        return "TL2-Collapse"
    elif colName == "MSRP-LP":
        return "LP:Mutex"
        #return "TORTIS-mutex"
    elif colName == "Phase-Fair-RW":
        return "Retry-free"
        #return "Retry-free (PF-RW)"
        #return "PF-RW"
        #return "LP:PF"
        #return "TORTIS"
        #return "PFRW linprog (TORTIS)"
    elif colName == "Phase-Fair-RW-Collapse":
        return "TORTIS-Collapse"
        #return "PFRW linprog collapse"
    elif colName == "pftl-blocking":
        return "Inflation:PF"
        #return "PF-RW Inflation"
    elif colName == "pftl-collapse":
        return "PFRW collapse"
    elif colName == "lockfree_NP":
        return "Retry"
    elif colName == "lockfree_NP_no_reads":
        return "Retry, no reads"
    else:
        return colName

def main():
    for file in sys.argv[1:]:
        # Get the experiment names
        f = open(file, 'r')
        for row in f:
            if string.join(row).strip().startswith('#') and "TASK" in row:
                title_row = row
        title_row = title_row[1:]
        split_title = title_row.split()
        split_title = split_title[1:]
        f.close()

        if "PFair" in split_title:
            split_title.remove("PFair")

        #print(split_title)

        if "MSRP-classic" in split_title:
            LINE_STYLE = ["s-", "^-",".:","^-", "o--", ".:", "p:"]
            LINE_COLOR = ["k", "#d95f02",'y','m', "#1b9e77", "#7570b3", "#7570a2"]
        elif "PFTL-LP" in split_title:
            LINE_STYLE = ["s-","s-","o--", "^--","o:", "^:","o:", ".:", "p:","o-","s:","^:"]
            LINE_COLOR = ["k", "b","r","#88e2df","#2e5aa8","k", "#d95f02", "#d95f02", "#1b9e77",  "#1b9e77","#7570b3", "#333333","r","b","m"]
        elif "PF-L-Overhead" in split_title:
            LINE_STYLE = ["s-","^--","s-", "^-","^:", "o--","o:", ".:", "p:","o-","s:","^:"]
            LINE_COLOR = ["k", "c", "b","#d95f02", "#d95f02", "#1b9e77",  "#1b9e77","#7570b3", "#333333","r","b","m"]
        else:
            LINE_STYLE = ["s-","o:","^--","s-", "^-","^:", "o--","o:", ".:", "p:","o-","s:","^:"]
            LINE_COLOR = ["k", "m","#2c9c9c", "b","#d95f02", "#d95f02", "#1b9e77",  "#1b9e77","#7570b3", "#333333","r","b","m"]

        f = open(file, 'r')
        
        x = []
        y = [[] for _ in range(0, len(split_title))]

        plots = csv.reader(f, delimiter=',')
        for row in plots:
            if not string.join(row).strip().startswith('#'):
                #print(row)
                x.append(float(row[0]))
                for i in range(0,len(row)-1):
                    y[i].append(float(row[i+1]))
                    #print(y[i])
        if len(x)>1:

            fig, ax = plt.subplots()
            fig.set_size_inches(WIDTH, HEIGHT)
            #plt.legend(loc="lower left")
            for i in range(0, len(split_title)):
                if split_title[i] in chosen_lines:
                    #print(x, y[i])
                    #try:
                    ax.plot(x,y[i], LINE_STYLE[i], color=LINE_COLOR[i], label=chooseLabel(split_title[i]))
                    #except:
                    #    print("could not graph")

            plt.legend(loc="best")
            plt.xticks(np.arange(min(x),max(x)+1, step=4))
            plt.yticks(np.arange(0,1.1,step=0.1))

            ax.grid(linestyle="dotted")
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
        
            plt.ylabel("Schedulability Ratio")
            plt.xlabel("Number of Tasks")

        # Try to make sure the x-axis label isn't cut off
            plt.tight_layout()

            plt.savefig(file[:-4]+".pdf", bbox_inches = 'tight', pad_inches = 0)
            plt.savefig(file[:-4]+".png", bbox_inches = 'tight', pad_inches = 0)
            plt.close()

if __name__ == '__main__':
    main()
