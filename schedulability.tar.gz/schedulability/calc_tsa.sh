#!/bin/bash

edir="output"
tdir="08_29_2021-14:12:21"

echo "Counting each csv"
python calc_tsa.py $edir/$tdir/*csv

