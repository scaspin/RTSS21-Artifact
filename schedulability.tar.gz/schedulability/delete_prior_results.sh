#!/bin/bash

timestamp="08_29_2021-14:1*"

plot_dir="plots/"$timestamp
conf_dir="confs/"$timestamp
output_dir="output/"$timestamp


#mkdir $edir/$timestamp

echo "Do you really want to delete all data associated with "$timestamp"? (y/n)"
read really_delete

if [ $really_delete = 'y' ]
then
    echo "Starting to delete data..."
    sleep 2  # Give user a couple of seconds to ^C
    echo
    echo "Removing "$conf_dir"/*"
    rm -r $conf_dir
    echo
    echo "Removing "$output_dir"/*"
    rm -r $output_dir
    echo
    echo "Removing "$plot_dir"/*"
    rm -r $plot_dir
fi

