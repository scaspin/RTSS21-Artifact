% The (old) Rust Guide

This content has moved into
[the Rust Programming Language book](book/README.html).
