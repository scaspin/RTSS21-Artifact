# The Rustdoc Book

- [What is rustdoc?](what-is-rustdoc.md)
- [Command-line arguments](command-line-arguments.md)
- [The `#[doc]` attribute](the-doc-attribute.md)
- [Documentation tests](documentation-tests.md)
- [Passes](passes.md)
- [Unstable features](unstable-features.md)
