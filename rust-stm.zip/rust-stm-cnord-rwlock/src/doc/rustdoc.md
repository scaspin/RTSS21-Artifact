% Rust Documentation

This has been moved [into the book](book/documentation.html).
