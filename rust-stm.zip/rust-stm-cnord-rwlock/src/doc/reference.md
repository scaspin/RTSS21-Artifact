% The Rust Reference has moved

We've split up the reference into chapters. Please find it at its new
home [here](reference/index.html).
