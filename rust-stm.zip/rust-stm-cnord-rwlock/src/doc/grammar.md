% Grammar

The Rust grammar may now be found in the [reference]. Additionally, the [grammar
working group] is working on producing a testable grammar.

[reference]: https://doc.rust-lang.org/reference/
[grammar working group]: https://github.com/rust-lang/wg-grammar
