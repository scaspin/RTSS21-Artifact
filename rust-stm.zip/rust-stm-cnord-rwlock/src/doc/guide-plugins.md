% The (old) Rust Compiler Plugins Guide

This content has moved into
[the Unstable Book](unstable-book/language-features/plugin.html).
