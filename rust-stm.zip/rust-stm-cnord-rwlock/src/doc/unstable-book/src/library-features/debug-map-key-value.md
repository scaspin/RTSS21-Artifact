# `debug_map_key_value`

The tracking issue for this feature is: [#62482]

[#62482]: https://github.com/rust-lang/rust/issues/62482

------------------------

Add the methods `key` and `value` to `DebugMap` so that an entry can be formatted across multiple calls without additional buffering.
