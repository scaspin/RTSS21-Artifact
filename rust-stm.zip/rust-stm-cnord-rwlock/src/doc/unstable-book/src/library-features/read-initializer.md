# `read_initializer`

The tracking issue for this feature is: [#42788]

[#0]: https://github.com/rust-lang/rust/issues/42788

------------------------
