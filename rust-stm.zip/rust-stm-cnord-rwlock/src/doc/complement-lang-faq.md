% The Rust Language FAQ

This content has moved to [the website](https://www.rust-lang.org/).
