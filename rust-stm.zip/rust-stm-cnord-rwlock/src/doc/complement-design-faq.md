% The Rust Design FAQ

This content has moved to [the website](https://www.rust-lang.org/).
