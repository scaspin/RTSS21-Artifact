//! The libcore prelude

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;
