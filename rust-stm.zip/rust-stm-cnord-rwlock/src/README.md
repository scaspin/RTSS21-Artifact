This directory contains the source code of the rust project, including:
- `rustc` and its tests
- `libstd`
- Various submodules for tools, like rustdoc, rls, etc.

For more information on how various parts of the compiler work, see the [rustc guide].

[rustc guide]: https://rust-lang.github.io/rustc-guide/about-this-guide.html
