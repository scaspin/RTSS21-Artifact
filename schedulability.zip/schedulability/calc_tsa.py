#!/usr/bin/env python
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import csv
import string
import math
from csv import DictReader
from copy import copy
from collections import defaultdict
#import sys
#from csv import DictReader
#from copy import copy
#from collections import defaultdict
#import string

protocols = ['NOLOCK','pftl-blocking','Phase-Fair-RW',"lockfree_NP","lockfree_NP_no_reads"]

CLOSE_CUTOFF = 0.5
ZERO_CUTOFF = 0.01

class Entry():
    def __init__(self, protocol_num, filename, error=None, second=None, SUA=None):
        self.protocol_num = protocol_num
        self.filename = filename
        self.error = error
        self.second = second
        self.SUA = SUA

def get_filename_contents(filename):
    output_str = ""
    filename = filename.split("/")[-1]
    filename = filename.split("per=")[1]
    output_str += filename.split("__nr=")[0]
    filename = filename.split("__nr=")[1]
    output_str += ", "
    output_str += filename.split("__pacc=")[0]
    filename = filename.split("__pacc=")[1]
    output_str += ", "
    output_str += filename.split("__cs=")[0]
    filename = filename.split("__cs=")[1]
    output_str += ", "
    output_str += filename.split("__nreq=")[0]
    filename = filename.split("__nreq=")[1]
    output_str += ", "
    output_str += filename.split("__write-perc=")[0]
    filename = filename.split("__write-perc=")[1]
    output_str += ", "
    output_str += filename.split("__read-cs-len=")[0]
    return output_str

def main():
    index_num = {}
    for num in range(len(protocols)):
        index_num[protocols[num]] = num
    num_wins = [0] * len(protocols)
    other_winners = []
    close_calls = []
    zero_util = []
    running_best_sum = 0

    f = open(sys.argv[1:][0], 'r')
    for row in f:
        if string.join(row).strip().startswith('#') and "TASK" in row:
            title_row = row
    title_row = title_row[1:]
    split_title = title_row.split()
    split_title = split_title[1:]
    f.close()

    print split_title

    output_str = ""
    for entry in protocols:
        output_str += str(protocols[index_num[entry]])+ ", "
    print output_str + " period, nr, pacc, cs, nreq, write-perc"
    
    for filename in sys.argv[1:]:
        f = open(filename, 'r')
        x = []
        y = [[] for _ in range(0, len(split_title))]
 
        plots = csv.reader(f, delimiter=',')
        for row in plots:
            if not string.join(row).strip().startswith('#'):
                x.append(float(row[0]))
                for i in range(0,len(row)-1):
                    y[i].append(float(row[i+1]))
        f.close()

        step_size = x[1]-x[0]
        data_dict = {}
        for line_name in protocols:
            for i in range(0, len(split_title)):
                if split_title[i] == line_name:
                    data_dict[line_name] = y[i]

        areas = [0]*len(protocols)
        for line_name in protocols:
            for i in range(0, len(data_dict[line_name])-1):
                rectangle_area = ((data_dict[line_name][i] + data_dict[line_name][i+1])/2.0)*step_size
                areas[index_num[line_name]] += rectangle_area

        # Print TSA per file
        output_str = ""
        for entry in protocols:
            output_str += str(areas[index_num[entry]])+ ", "
        print output_str + get_filename_contents(filename)


if __name__ == '__main__':
    main()
