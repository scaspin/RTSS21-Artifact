#!/bin/bash

timestamp=$(date +"%m_%d_%Y-%H:%M:%S")
plot_dir="plots/"$timestamp
conf_dir="confs/"$timestamp
output_dir="output/"$timestamp

mkdir $output_dir

general_out=$output_dir/"stdout+stderr.out"

tempvar=$(printenv | grep PYTHONPATH)
if [ -z $PYTHONPATH ]
then
    echo "Setting PYTHONPATH" >> $general_out
    export PYTHONPATH=./lib/schedcat
fi

# Copy over setup file
cp exp/pedf_lp.py $output_dir/pedf_lp.py

# Generate configs
python -m exp -g pedf-lp/tcount -d $timestamp -o $timestamp > $general_out 2>&1
echo "Done generating configs" >> $general_out

# Run experiment
python -m exp -p -d $conf_dir/ >> $general_out 2>&1
echo "Done running experiment" >> $general_out


# Graph results
python gen_graphs_all.py $output_dir/*csv >> $general_out 2>&1
echo "Done making graphs" >> $general_out

# Move results to plot_dir
mkdir $plot_dir >> $general_out 2>&1
mv $output_dir/*pdf $plot_dir >> $general_out 2>&1
mv $output_dir/*png $plot_dir >> $general_out 2>&1
echo "Done moving graphs" >> $general_out
