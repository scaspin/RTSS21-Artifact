#!/usr/bin/env python

import unittest


import tests.pedf_spinlocks

suite = unittest.TestSuite(
    [unittest.defaultTestLoader.loadTestsFromModule(x) for x in
     [tests.pedf_spinlocks]
    ])

def run_all_tests():
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    run_all_tests()
